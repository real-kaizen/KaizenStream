package com.kaizen.stream

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject

data class LibItem(
    val url: String,
    val title: String,
    val pos: Long,
    val dur: Long,
    val time: Long,
    val playlist: Boolean
) {
    val domain: String get() = domainOf(url)
    val progress: Int get() = if (dur > 0) ((pos * 100) / dur).toInt().coerceIn(0, 100) else 0
}

fun domainOf(url: String): String =
    try {
        Uri.parse(url).host?.removePrefix("www.") ?: url
    } catch (e: Exception) {
        url
    }

fun titleOf(url: String): String {
    val n = Uri.decode(url.substringBefore('?').trimEnd('/').substringAfterLast('/'))
    return if (n.isBlank()) domainOf(url) else n
}

fun fmtTime(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) String.format("%d:%02d:%02d", h, m, sec) else String.format("%02d:%02d", m, sec)
}

/** Playback history with resume positions. */
class Library(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("kaizen_library", Context.MODE_PRIVATE)

    fun all(): MutableList<LibItem> {
        val out = ArrayList<LibItem>()
        try {
            val arr = JSONArray(sp.getString("items", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    LibItem(
                        o.getString("url"), o.optString("title"), o.optLong("pos"),
                        o.optLong("dur"), o.optLong("time"), o.optBoolean("pl")
                    )
                )
            }
        } catch (e: Exception) {
        }
        return out
    }

    private fun save(list: List<LibItem>) {
        val arr = JSONArray()
        for (x in list.take(100)) {
            arr.put(
                JSONObject().put("url", x.url).put("title", x.title).put("pos", x.pos)
                    .put("dur", x.dur).put("time", x.time).put("pl", x.playlist)
            )
        }
        sp.edit().putString("items", arr.toString()).apply()
    }

    fun find(url: String): LibItem? = all().firstOrNull { it.url == url }

    /** Adds the item (or moves it to the top) and keeps its saved position. */
    fun touch(url: String, title: String, playlist: Boolean = false) {
        val list = all()
        val old = list.firstOrNull { it.url == url }
        list.removeAll { it.url == url }
        list.add(
            0,
            LibItem(
                url, if (title.isNotBlank()) title else (old?.title ?: titleOf(url)),
                old?.pos ?: 0L, old?.dur ?: 0L, System.currentTimeMillis(), playlist || (old?.playlist ?: false)
            )
        )
        save(list)
    }

    fun saveProgress(url: String, title: String, pos: Long, dur: Long) {
        if (dur <= 0L) return
        val list = all()
        val old = list.firstOrNull { it.url == url }
        val p = if (pos > dur * 95 / 100 || pos < 3_000L) 0L else pos
        list.removeAll { it.url == url }
        list.add(
            0,
            LibItem(
                url, if (title.isNotBlank()) title else (old?.title ?: titleOf(url)),
                p, dur, System.currentTimeMillis(), old?.playlist ?: false
            )
        )
        save(list)
    }

    fun remove(url: String) {
        val list = all()
        list.removeAll { it.url == url }
        save(list)
    }

    fun clear() = save(emptyList())
}
