package com.kaizen.stream

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.ViewGroup
import android.view.LayoutInflater
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class PlaylistActivity : AppCompatActivity() {

    private val all: List<Entry> = PlaylistHolder.entries
    private lateinit var adapter: ChannelAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (all.isEmpty()) {
            finish()
            return
        }
        setContentView(R.layout.activity_playlist)

        findViewById<View>(R.id.backBtn).setOnClickListener { finish() }
        findViewById<TextView>(R.id.listTitle).text = PlaylistHolder.title.ifEmpty { "Playlist" }
        findViewById<TextView>(R.id.listCount).text = "${all.size} items"

        adapter = ChannelAdapter()
        val list = findViewById<ListView>(R.id.list)
        list.adapter = adapter
        adapter.addAll(all)

        list.setOnItemClickListener { _, _, position, _ ->
            val e = adapter.getItem(position) ?: return@setOnItemClickListener
            val index = all.indexOfFirst { it === e }.coerceAtLeast(0)
            startActivity(Launcher.playlistIntent(this, index))
        }

        findViewById<EditText>(R.id.searchInput).addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val q = s?.toString()?.trim().orEmpty()
                adapter.clear()
                if (q.isEmpty()) adapter.addAll(all)
                else adapter.addAll(all.filter { it.title.contains(q, ignoreCase = true) })
                adapter.notifyDataSetChanged()
            }
        })
    }

    private inner class ChannelAdapter : ArrayAdapter<Entry>(this@PlaylistActivity, R.layout.item_recent) {
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val v = convertView ?: LayoutInflater.from(context).inflate(R.layout.item_recent, parent, false)
            getItem(position)?.let { ItemBinder.bindEntry(v, it) }
            return v
        }
    }
}
