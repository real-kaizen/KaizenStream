package com.kaizen.stream

import android.app.Activity
import android.content.Intent
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat

/** Bottom navigation: Home / History / Settings. Home is the root screen. */
object BottomNav {

    fun setup(a: Activity, selected: Int) {
        val ids = intArrayOf(R.id.navHome, R.id.navHistory, R.id.navSettings)
        for (id in ids) {
            val item = a.findViewById<ViewGroup>(id)
            val color = ContextCompat.getColor(a, if (id == selected) R.color.accent else R.color.muted)
            (item.getChildAt(0) as ImageView).setColorFilter(color)
            (item.getChildAt(1) as TextView).setTextColor(color)
            item.setOnClickListener { go(a, selected, id) }
        }
    }

    private fun go(a: Activity, selected: Int, target: Int) {
        if (target == selected) return
        if (target == R.id.navHome) {
            a.finish()
            a.overridePendingTransition(0, 0)
            return
        }
        val cls = if (target == R.id.navHistory) HistoryActivity::class.java else SettingsActivity::class.java
        a.startActivity(Intent(a, cls))
        a.overridePendingTransition(0, 0)
        if (selected != R.id.navHome) a.finish()
    }
}
