package com.kaizen.stream

import android.net.TrafficStats
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.os.SystemClock
import android.view.View
import android.widget.ProgressBar
import android.widget.TextView

/**
 * Loading / buffering screen: live download speed (measured from the app's real network traffic),
 * data loaded so far, a progress bar and a "taking long?" hint. Used by both playback engines.
 */
class LoadingMonitor(
    private val panel: View,
    private val titleView: TextView,
    private val speedView: TextView,
    private val detailView: TextView,
    private val progressView: ProgressBar,
    val hintView: TextView
) {
    var stage: String = "Loading…"
    var percent: Int = -1          // -1 = unknown (animated bar)
    var extra: String = ""

    val isShowing: Boolean
        get() = running

    private val handler = Handler(Looper.getMainLooper())
    private val uid = Process.myUid()
    private var running = false
    private var lastBytes = 0L
    private var lastMs = 0L
    private var startBytes = 0L
    private var startMs = 0L
    private var speedBps = 0f
    private var slowAfterMs = 0L
    private var onSlow: (() -> Unit)? = null
    private var slowFired = false

    private val tick = object : Runnable {
        override fun run() {
            update()
            if (running) handler.postDelayed(this, 500)
        }
    }

    fun show(stage: String, slowAfterMs: Long = 0L, onSlow: (() -> Unit)? = null) {
        this.stage = stage
        if (running) return
        running = true
        this.slowAfterMs = slowAfterMs
        this.onSlow = onSlow
        slowFired = false
        speedBps = 0f
        percent = -1
        extra = ""
        lastBytes = TrafficStats.getUidRxBytes(uid)
        startBytes = lastBytes
        lastMs = SystemClock.elapsedRealtime()
        startMs = lastMs
        hintView.visibility = View.GONE
        panel.visibility = View.VISIBLE
        handler.removeCallbacks(tick)
        handler.post(tick)
    }

    fun hide() {
        running = false
        handler.removeCallbacks(tick)
        panel.visibility = View.GONE
        hintView.visibility = View.GONE
    }

    private fun update() {
        val now = SystemClock.elapsedRealtime()
        val bytes = TrafficStats.getUidRxBytes(uid)
        val supported = bytes >= 0L && lastBytes >= 0L
        if (supported) {
            val dt = (now - lastMs) / 1000f
            if (dt > 0f) {
                val inst = ((bytes - lastBytes) / dt).coerceAtLeast(0f)
                speedBps = if (speedBps == 0f) inst else speedBps * 0.6f + inst * 0.4f
            }
            lastBytes = bytes
        }
        lastMs = now

        titleView.text = if (percent >= 0) "$stage  $percent%" else stage
        speedView.text = if (supported) fmtSpeed(speedBps) else "—"
        val parts = ArrayList<String>()
        if (supported) parts.add("Loaded " + fmtBytes((bytes - startBytes).coerceAtLeast(0L)))
        if (extra.isNotBlank()) parts.add(extra)
        parts.add("${(now - startMs) / 1000}s")
        detailView.text = parts.joinToString("  •  ")

        if (percent >= 0) {
            progressView.isIndeterminate = false
            progressView.progress = percent.coerceIn(0, 100)
        } else {
            progressView.isIndeterminate = true
        }

        val waited = now - startMs
        if (waited > 6_000L) hintView.visibility = View.VISIBLE
        if (!slowFired && slowAfterMs > 0L && waited >= slowAfterMs) {
            slowFired = true
            onSlow?.invoke()
        }
    }

    private fun fmtBytes(b: Long): String = when {
        b >= 1_073_741_824L -> String.format("%.2f GB", b / 1_073_741_824f)
        b >= 1_048_576L -> String.format("%.1f MB", b / 1_048_576f)
        else -> String.format("%d KB", b / 1024)
    }

    private fun fmtSpeed(bps: Float): String =
        if (bps >= 1_048_576f) String.format("%.1f MB/s  (%.0f Mbps)", bps / 1_048_576f, bps * 8f / 1_000_000f)
        else String.format("%.0f KB/s", bps / 1024f)
}
