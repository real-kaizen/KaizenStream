package com.kaizen.stream

import android.content.Context

class HistoryStore(context: Context) {
    private val prefs = context.getSharedPreferences("kaizen_history", Context.MODE_PRIVATE)

    fun getAll(): MutableList<String> =
        (prefs.getString(KEY, "") ?: "")
            .split("\n")
            .filter { it.isNotBlank() }
            .toMutableList()

    fun add(url: String) {
        val list = getAll()
        list.remove(url)
        list.add(0, url)
        save(list.take(MAX))
    }

    fun remove(url: String) {
        val list = getAll()
        list.remove(url)
        save(list)
    }

    fun clear() = save(emptyList())

    private fun save(list: List<String>) {
        prefs.edit().putString(KEY, list.joinToString("\n")).apply()
    }

    companion object {
        private const val KEY = "urls"
        private const val MAX = 30
    }
}
