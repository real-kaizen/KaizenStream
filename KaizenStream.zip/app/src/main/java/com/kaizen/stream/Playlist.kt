package com.kaizen.stream

import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL

data class Entry(val title: String, val url: String)

object PlaylistHolder {
    var title: String = ""
    var entries: List<Entry> = emptyList()
}

object PlaylistParser {

    /** True if the text is an HLS stream manifest rather than a channel list. */
    fun looksLikeHls(text: String): Boolean =
        text.contains("#EXT-X-STREAM-INF") ||
            text.contains("#EXT-X-TARGETDURATION") ||
            text.contains("#EXT-X-MEDIA-SEQUENCE")

    fun parse(text: String, baseUrl: String?): List<Entry> {
        val out = ArrayList<Entry>()
        var title: String? = null
        for (raw in text.lineSequence()) {
            val line = raw.trim().removePrefix("\uFEFF")
            if (line.isEmpty()) continue
            if (line.startsWith("#EXTINF", ignoreCase = true)) {
                var t: String? = line.substringAfterLast(',', "").trim().ifEmpty { null }
                if (t == null) {
                    t = Regex("tvg-name=\"([^\"]*)\"").find(line)?.groupValues?.get(1)
                }
                title = t
            } else if (line.startsWith("#")) {
                continue
            } else {
                val url = resolve(line, baseUrl) ?: continue
                val name = title ?: url.substringAfterLast('/').substringBefore('?').ifEmpty { url }
                out.add(Entry(name, url))
                title = null
            }
        }
        return out
    }

    private fun resolve(line: String, base: String?): String? {
        if (line.startsWith("http://", true) || line.startsWith("https://", true)) return line
        if (base == null) return null
        return try {
            URI(base).resolve(line).toString()
        } catch (e: Exception) {
            null
        }
    }
}

data class Probe(val code: Int, val rangeOk: Boolean, val size: Long)

object Net {

    /** Asks the server for 1 byte (Range request) to learn if it supports seeking, and the file size. */
    fun probe(url: String): Probe? {
        return try {
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 10_000
            c.readTimeout = 10_000
            c.instanceFollowRedirects = true
            c.setRequestProperty("Range", "bytes=0-0")
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13) KaizenStream/3.3")
            try {
                val code = c.responseCode
                val range = c.getHeaderField("Content-Range")
                val size = range?.substringAfterLast('/')?.toLongOrNull()
                    ?: c.getHeaderField("Content-Length")?.toLongOrNull()
                    ?: -1L
                Probe(code, code == 206, size)
            } finally {
                c.disconnect()
            }
        } catch (e: Exception) {
            null
        }
    }

    fun describe(p: Probe?): String {
        if (p == null) return "Server check failed"
        val size = if (p.size > 0) String.format("%.1f GB", p.size / 1_000_000_000.0) else "size unknown"
        return when {
            p.rangeOk -> "Server OK  •  seeking supported  •  $size"
            p.code == 200 -> "⚠ Server ignores range requests  •  $size\nBig files can't start or seek reliably"
            p.code == 401 || p.code == 403 -> "⚠ HTTP ${p.code}  •  link expired or blocked"
            else -> "HTTP ${p.code}"
        }
    }

    fun fetchText(url: String, maxBytes: Int = 12_000_000): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15_000
        c.readTimeout = 20_000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13) KaizenStream/2.0")
        try {
            if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
            val buf = ByteArray(16 * 1024)
            val out = ByteArrayOutputStream()
            c.inputStream.use { input ->
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    if (out.size() > maxBytes) break
                }
            }
            return out.toString("UTF-8")
        } finally {
            c.disconnect()
        }
    }
}
