package com.kaizen.stream

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.content.ContextCompat
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class SettingsActivity : AppCompatActivity() {

    private lateinit var container: LinearLayout

    private val langs = listOf(
        "" to "Default", "hi" to "Hindi", "en" to "English", "ta" to "Tamil", "te" to "Telugu",
        "kn" to "Kannada", "ml" to "Malayalam", "bn" to "Bengali", "pa" to "Punjabi", "mr" to "Marathi",
        "ur" to "Urdu", "es" to "Spanish", "fr" to "French", "ar" to "Arabic", "ja" to "Japanese", "ko" to "Korean"
    )
    private val speeds = floatArrayOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)
    private val buffers = intArrayOf(3000, 8000, 20000, 40000)
    private val scalingNames = arrayOf("Fit to screen", "Stretch", "Zoom")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        container = findViewById(R.id.settingsList)
        findViewById<View>(R.id.backBtn).setOnClickListener { finish() }
        BottomNav.setup(this, R.id.navSettings)
        render()
    }

    private fun speedLabel(v: Float) = if (v == 1f) "1.0x" else "${v}x"

    private fun render() {
        container.removeAllViews()

        val playback = group("PLAYBACK")
        row(playback, R.drawable.ic_swap, "Playback engine", engineLabel(), null) { pickEngine() }
        row(playback, R.drawable.ic_audio, "Audio track", langLabel(Prefs.audioLang(this)), null) { pickAudio() }
        row(playback, R.drawable.ic_subtitles, "Subtitle", if (Prefs.subLang(this) == "off") "Off" else langLabel(Prefs.subLang(this)), null) { pickSubtitle() }
        row(playback, R.drawable.ic_aspect, "Video scaling", scalingNames[Prefs.scaling(this).coerceIn(0, 2)], null) { pickScaling() }
        row(playback, R.drawable.ic_speed, "Playback speed", speedLabel(Prefs.speed(this)), null) { pickSpeed() }
        row(playback, R.drawable.ic_history, "Resume playback", "Continue from where you stopped", Prefs.resume(this)) { sw ->
            Prefs.putBool(this, "resume", sw)
        }

        val engine = group("DECODING AND NETWORK")
        row(engine, R.drawable.ic_memory, "Hardware decoding", if (Prefs.hw(this)) "Prefer hardware" else "Prefer software", Prefs.hw(this)) { sw ->
            Prefs.putBool(this, "vlc_hw", sw)
            render()
        }
        row(engine, R.drawable.ic_link, "Smart network (VLC)", "Read ahead with the ExoPlayer-style loader", Prefs.smart(this)) { sw ->
            Prefs.putBool(this, "vlc_smart", sw)
        }
        row(engine, R.drawable.ic_speed, "VLC buffer", "${Prefs.bufferMs(this) / 1000} s", null) { pickBuffer() }

        val data = group("DATA")
        row(data, R.drawable.ic_delete, "Clear playback history", null, null) { confirmClear() }
        row(data, R.drawable.ic_info, "About Kaizen Stream", null, null) {
            startActivity(Intent(this, AboutActivity::class.java))
        }
    }

    private fun group(title: String): LinearLayout {
        val label = TextView(this).apply {
            text = title
            setTextColor(ContextCompat.getColor(context, R.color.muted))
            textSize = 12f
            letterSpacing = 0.12f
            setPadding(6, if (container.childCount == 0) 8 else 56, 0, 24)
        }
        container.addView(label)
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.card_bg)
        }
        container.addView(card)
        return card
    }

    private fun row(
        card: LinearLayout,
        icon: Int,
        title: String,
        value: String?,
        toggle: Boolean?,
        onClick: (Boolean) -> Unit
    ) {
        if (card.childCount > 0) {
            val d = View(this)
            d.setBackgroundColor(ContextCompat.getColor(this, R.color.hairline))
            card.addView(d, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1))
        }
        val v = layoutInflater.inflate(R.layout.item_setting, card, false)
        v.findViewById<ImageView>(R.id.setIcon).setImageResource(icon)
        v.findViewById<TextView>(R.id.setTitle).text = title
        val vt = v.findViewById<TextView>(R.id.setValue)
        if (value == null) vt.visibility = View.GONE else vt.text = value
        val sw = v.findViewById<SwitchCompat>(R.id.setSwitch)
        if (toggle != null) {
            sw.visibility = View.VISIBLE
            sw.isChecked = toggle
            v.findViewById<View>(R.id.setChevron).visibility = View.GONE
        }
        v.setOnClickListener {
            if (toggle != null) {
                sw.isChecked = !sw.isChecked
                onClick(sw.isChecked)
            } else onClick(false)
        }
        card.addView(v)
    }

    private fun choose(title: String, labels: Array<String>, checked: Int, onPick: (Int) -> Unit) {
        MaterialAlertDialogBuilder(this)
            .setTitle(title)
            .setSingleChoiceItems(labels, checked) { d, which ->
                onPick(which)
                d.dismiss()
                render()
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun engineLabel() = when (Prefs.engine(this)) {
        "exo" -> "ExoPlayer only"
        "vlc" -> "VLC only"
        else -> "Auto (recommended)"
    }

    private fun langLabel(code: String) = langs.firstOrNull { it.first == code }?.second ?: "Default"

    private fun pickEngine() {
        val keys = arrayOf("auto", "exo", "vlc")
        val labels = arrayOf("Auto (recommended)", "ExoPlayer only", "VLC only")
        choose("Playback engine", labels, keys.indexOf(Prefs.engine(this)).coerceAtLeast(0)) {
            Prefs.putString(this, "engine", keys[it])
        }
    }

    private fun pickAudio() {
        val labels = langs.map { it.second }.toTypedArray()
        choose("Audio track", labels, langs.indexOfFirst { it.first == Prefs.audioLang(this) }.coerceAtLeast(0)) {
            Prefs.putString(this, "audio_lang", langs[it].first)
        }
    }

    private fun pickSubtitle() {
        val opts = listOf("off" to "Off") + langs.filter { it.first.isNotEmpty() }
        val labels = opts.map { it.second }.toTypedArray()
        choose("Subtitle", labels, opts.indexOfFirst { it.first == Prefs.subLang(this) }.coerceAtLeast(0)) {
            Prefs.putString(this, "sub_lang", opts[it].first)
        }
    }

    private fun pickScaling() {
        choose("Video scaling", scalingNames, Prefs.scaling(this).coerceIn(0, 2)) {
            Prefs.putInt(this, "scaling", it)
        }
    }

    private fun pickSpeed() {
        val labels = speeds.map { speedLabel(it) }.toTypedArray()
        val checked = speeds.indexOfFirst { it == Prefs.speed(this) }.let { if (it < 0) 2 else it }
        choose("Playback speed", labels, checked) { Prefs.putFloat(this, "speed", speeds[it]) }
    }

    private fun pickBuffer() {
        val labels = buffers.map { "${it / 1000} seconds" }.toTypedArray()
        choose("VLC buffer", labels, buffers.indexOf(Prefs.bufferMs(this)).coerceAtLeast(0)) {
            Prefs.putInt(this, "vlc_buffer", buffers[it])
        }
    }

    private fun confirmClear() {
        MaterialAlertDialogBuilder(this)
            .setTitle("Clear playback history?")
            .setMessage("This removes all items and saved resume positions.")
            .setPositiveButton("Clear") { _, _ ->
                Library(this).clear()
                Toast.makeText(this, "History cleared", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
