package com.kaizen.stream

import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView

@OptIn(UnstableApi::class)
class PlayerActivity : AppCompatActivity() {

    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var errorText: TextView
    private var url: String = ""
    private var resumePosition = 0L
    private var resumePlaying = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)
        playerView = findViewById(R.id.playerView)
        errorText = findViewById(R.id.errorText)

        val u = intent.getStringExtra(EXTRA_URL) ?: intent.dataString
        if (u.isNullOrBlank()) {
            finish()
            return
        }
        url = u
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        errorText.setOnClickListener { retry() }
        savedInstanceState?.let {
            resumePosition = it.getLong(KEY_POS)
            resumePlaying = it.getBoolean(KEY_PLAY, true)
        }
        hideSystemBars()
        playerView.requestFocus()
    }

    override fun onStart() {
        super.onStart()
        initPlayer()
    }

    override fun onStop() {
        super.onStop()
        releasePlayer()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        player?.let {
            resumePosition = it.currentPosition
            resumePlaying = it.playWhenReady
        }
        outState.putLong(KEY_POS, resumePosition)
        outState.putBoolean(KEY_PLAY, resumePlaying)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    private fun hideSystemBars() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            hide(WindowInsetsCompat.Type.systemBars())
        }
    }

    private fun initPlayer() {
        if (player != null || url.isEmpty()) return

        val http = DefaultHttpDataSource.Factory()
            .setUserAgent("Mozilla/5.0 (Linux; Android 13) KaizenStream/1.0")
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15_000)
            .setReadTimeoutMs(15_000)

        val renderers = DefaultRenderersFactory(this).setEnableDecoderFallback(true)

        val p = ExoPlayer.Builder(this, renderers)
            .setMediaSourceFactory(DefaultMediaSourceFactory(DefaultDataSource.Factory(this, http)))
            .setSeekBackIncrementMs(10_000)
            .setSeekForwardIncrementMs(10_000)
            .build()

        p.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                errorText.text = "Can't play this link\n\n${error.errorCodeName}\n" +
                    "${error.cause?.message ?: error.message ?: ""}\n\nTap to retry"
                errorText.visibility = View.VISIBLE
            }

            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY) errorText.visibility = View.GONE
            }
        })

        playerView.player = p
        p.setMediaItem(MediaItem.fromUri(url))
        if (resumePosition > 0) p.seekTo(resumePosition)
        p.playWhenReady = resumePlaying
        p.prepare()
        player = p
    }

    private fun releasePlayer() {
        player?.let {
            resumePosition = it.currentPosition
            resumePlaying = it.playWhenReady
            playerView.player = null
            it.release()
        }
        player = null
    }

    private fun retry() {
        errorText.visibility = View.GONE
        player?.let {
            it.prepare()
            it.play()
        }
    }

    // TV remote: left/right seek 10s when the controls are hidden
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val p = player
        if (p != null && event.action == KeyEvent.ACTION_DOWN && !playerView.isControllerFullyVisible) {
            when (event.keyCode) {
                KeyEvent.KEYCODE_DPAD_LEFT -> {
                    p.seekTo((p.currentPosition - 10_000).coerceAtLeast(0))
                    return true
                }
                KeyEvent.KEYCODE_DPAD_RIGHT -> {
                    p.seekTo(p.currentPosition + 10_000)
                    return true
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    companion object {
        const val EXTRA_URL = "extra_url"
        private const val KEY_POS = "pos"
        private const val KEY_PLAY = "play"
    }
}
