package com.kaizen.stream

import android.annotation.SuppressLint
import android.app.PictureInPictureParams
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.Rational
import android.view.GestureDetector
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import io.github.anilbeesetti.nextlib.media3ext.ffdecoder.NextRenderersFactory
import kotlin.math.abs
import kotlin.math.roundToInt

@OptIn(UnstableApi::class)
class PlayerActivity : AppCompatActivity() {

    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var errorText: TextView
    private lateinit var hudText: TextView
    private lateinit var titleText: TextView
    private lateinit var topBar: View
    private lateinit var loader: View
    private lateinit var audio: AudioManager
    private lateinit var gestures: GestureDetector

    private var singleUrl = ""
    private var subUrl: String? = null
    private var playlist: List<Entry> = emptyList()
    private var resumeIndex = 0
    private var resumePosition = 0L
    private var resumePlaying = true

    private var resizeIdx = 0
    private val resizeModes = intArrayOf(
        AspectRatioFrameLayout.RESIZE_MODE_FIT,
        AspectRatioFrameLayout.RESIZE_MODE_FILL,
        AspectRatioFrameLayout.RESIZE_MODE_ZOOM
    )
    private val resizeNames = arrayOf("Fit", "Stretch", "Zoom")

    // gesture state: 0 = none, -1 = ignored, 1 = brightness, 2 = volume, 3 = seek
    private var gestureMode = 0
    private var seekStart = 0L
    private var seekTarget = 0L
    private var startBrightness = 0.5f
    private var startVolume = 0f
    private val hideHud = Runnable { hudText.visibility = View.GONE }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)
        playerView = findViewById(R.id.playerView)
        errorText = findViewById(R.id.errorText)
        hudText = findViewById(R.id.hudText)
        titleText = findViewById(R.id.titleText)
        topBar = findViewById(R.id.topBar)
        loader = findViewById(R.id.loader)
        audio = getSystemService(AUDIO_SERVICE) as AudioManager

        if (intent.getBooleanExtra(EXTRA_PLAYLIST, false)) {
            playlist = PlaylistHolder.entries
            resumeIndex = intent.getIntExtra(EXTRA_INDEX, 0).coerceIn(0, (playlist.size - 1).coerceAtLeast(0))
        } else {
            singleUrl = intent.getStringExtra(EXTRA_URL) ?: intent.dataString ?: ""
            subUrl = intent.getStringExtra(EXTRA_SUB)
        }
        if (playlist.isEmpty() && singleUrl.isBlank()) {
            finish()
            return
        }

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        errorText.setOnClickListener { retry() }
        savedInstanceState?.let {
            resumeIndex = it.getInt(KEY_INDEX, resumeIndex)
            resumePosition = it.getLong(KEY_POS)
            resumePlaying = it.getBoolean(KEY_PLAY, true)
        }

        playerView.setControllerVisibilityListener(
            PlayerView.ControllerVisibilityListener { v -> topBar.visibility = v }
        )
        findViewById<View>(R.id.aspectBtn).setOnClickListener { cycleResize() }
        val pipBtn = findViewById<View>(R.id.pipBtn)
        if (Build.VERSION.SDK_INT >= 26) pipBtn.setOnClickListener { enterPip() }
        else pipBtn.visibility = View.GONE

        setupGestures()
        hideSystemBars()
        playerView.requestFocus()
    }

    override fun onStart() {
        super.onStart()
        initPlayer()
    }

    override fun onStop() {
        super.onStop()
        releasePlayer()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        player?.let {
            resumeIndex = it.currentMediaItemIndex
            resumePosition = it.currentPosition
            resumePlaying = it.playWhenReady
        }
        outState.putInt(KEY_INDEX, resumeIndex)
        outState.putLong(KEY_POS, resumePosition)
        outState.putBoolean(KEY_PLAY, resumePlaying)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (Build.VERSION.SDK_INT >= 26 && player?.isPlaying == true) enterPip()
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        playerView.useController = !isInPictureInPictureMode
        if (isInPictureInPictureMode) {
            topBar.visibility = View.GONE
            hudText.visibility = View.GONE
        }
    }

    private fun hideSystemBars() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            hide(WindowInsetsCompat.Type.systemBars())
        }
    }

    // ---------- player ----------

    private fun buildItems(): List<MediaItem> {
        if (playlist.isNotEmpty()) {
            return playlist.map {
                MediaItem.Builder()
                    .setUri(it.url)
                    .setMediaMetadata(MediaMetadata.Builder().setTitle(it.title).build())
                    .build()
            }
        }
        val b = MediaItem.Builder()
            .setUri(singleUrl)
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle(singleUrl.substringBefore('?').substringAfterLast('/'))
                    .build()
            )
        val sub = subUrl
        if (!sub.isNullOrBlank()) {
            val l = sub.substringBefore('?').lowercase()
            val mime = when {
                l.endsWith(".vtt") -> MimeTypes.TEXT_VTT
                l.endsWith(".ass") || l.endsWith(".ssa") -> MimeTypes.TEXT_SSA
                l.endsWith(".ttml") || l.endsWith(".xml") || l.endsWith(".dfxp") -> MimeTypes.APPLICATION_TTML
                else -> MimeTypes.APPLICATION_SUBRIP
            }
            b.setSubtitleConfigurations(
                listOf(
                    MediaItem.SubtitleConfiguration.Builder(Uri.parse(sub))
                        .setMimeType(mime)
                        .setLanguage("und")
                        .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                        .build()
                )
            )
        }
        return listOf(b.build())
    }

    private fun initPlayer() {
        if (player != null) return

        val http = DefaultHttpDataSource.Factory()
            .setUserAgent("Mozilla/5.0 (Linux; Android 13) KaizenStream/2.0")
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15_000)
            .setReadTimeoutMs(15_000)

        // Hardware decoders first; FFmpeg software decoders as fallback (DTS, TrueHD, AC3...)
        val renderers = NextRenderersFactory(this)
        renderers.setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
        renderers.setEnableDecoderFallback(true)

        val p = ExoPlayer.Builder(this, renderers)
            .setMediaSourceFactory(DefaultMediaSourceFactory(DefaultDataSource.Factory(this, http)))
            .setSeekBackIncrementMs(10_000)
            .setSeekForwardIncrementMs(10_000)
            .build()

        p.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                loader.visibility = View.GONE
                var msg = "Can't play this\n\n${error.errorCodeName}\n" +
                    (error.cause?.message ?: error.message ?: "") + "\n\nTap to retry"
                if (playlist.isNotEmpty()) msg += " • or press next to skip"
                errorText.text = msg
                errorText.visibility = View.VISIBLE
            }

            override fun onPlaybackStateChanged(state: Int) {
                loader.visibility = if (state == Player.STATE_BUFFERING) View.VISIBLE else View.GONE
                if (state == Player.STATE_READY) errorText.visibility = View.GONE
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                titleText.text = mediaItem?.mediaMetadata?.title ?: ""
                errorText.visibility = View.GONE
                player?.let { if (it.playbackState == Player.STATE_IDLE) it.prepare() }
            }
        })

        playerView.player = p
        p.setMediaItems(buildItems(), resumeIndex, if (resumePosition > 0) resumePosition else C.TIME_UNSET)
        p.playWhenReady = resumePlaying
        p.prepare()
        player = p
    }

    private fun releasePlayer() {
        player?.let {
            resumeIndex = it.currentMediaItemIndex
            resumePosition = it.currentPosition
            resumePlaying = it.playWhenReady
            playerView.player = null
            it.release()
        }
        player = null
    }

    private fun retry() {
        errorText.visibility = View.GONE
        player?.let {
            it.prepare()
            it.play()
        }
    }

    // ---------- aspect ratio / PiP ----------

    private fun cycleResize() {
        resizeIdx = (resizeIdx + 1) % resizeModes.size
        playerView.resizeMode = resizeModes[resizeIdx]
        showHud(resizeNames[resizeIdx])
    }

    private fun enterPip() {
        if (Build.VERSION.SDK_INT < 26 ||
            !packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)
        ) {
            Toast.makeText(this, "Picture-in-picture isn't supported here", Toast.LENGTH_SHORT).show()
            return
        }
        val vs = player?.videoSize
        var r = if (vs != null && vs.width > 0 && vs.height > 0) vs.width.toFloat() / vs.height else 16f / 9f
        r = r.coerceIn(0.45f, 2.3f)
        try {
            enterPictureInPictureMode(
                PictureInPictureParams.Builder()
                    .setAspectRatio(Rational((r * 1000).toInt(), 1000))
                    .build()
            )
        } catch (e: Exception) {
            Toast.makeText(this, "Turn on picture-in-picture for this app in Settings", Toast.LENGTH_LONG).show()
        }
    }

    // ---------- touch gestures ----------

    private fun showHud(text: String) {
        hudText.text = text
        hudText.visibility = View.VISIBLE
        hudText.removeCallbacks(hideHud)
        hudText.postDelayed(hideHud, 900)
    }

    private fun fmt(ms: Long): String {
        val s = (ms / 1000).coerceAtLeast(0)
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) String.format("%d:%02d:%02d", h, m, sec) else String.format("%02d:%02d", m, sec)
    }

    private fun currentBrightness(): Float {
        val b = window.attributes.screenBrightness
        if (b >= 0f) return b
        return try {
            Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS) / 255f
        } catch (e: Exception) {
            0.5f
        }
    }

    private fun setBrightness(v: Float) {
        val lp = window.attributes
        lp.screenBrightness = v
        window.attributes = lp
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupGestures() {
        gestures = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (playerView.isControllerFullyVisible) playerView.hideController()
                else playerView.showController()
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                val p = player ?: return true
                val w = playerView.width.toFloat()
                when {
                    e.x < w / 3f -> {
                        p.seekTo((p.currentPosition - 10_000).coerceAtLeast(0))
                        showHud("⏪  10s")
                    }
                    e.x > w * 2f / 3f -> {
                        p.seekTo(p.currentPosition + 10_000)
                        showHud("10s  ⏩")
                    }
                    else -> if (p.isPlaying) p.pause() else p.play()
                }
                return true
            }

            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
                val start = e1 ?: return false
                val p = player ?: return false
                val totalX = e2.x - start.x
                val totalY = e2.y - start.y
                if (gestureMode == 0) {
                    if (abs(totalX) > abs(totalY)) {
                        gestureMode = if (p.isCurrentMediaItemSeekable && p.duration != C.TIME_UNSET) 3 else -1
                        seekStart = p.currentPosition
                    } else {
                        gestureMode = if (start.x < playerView.width / 2f) 1 else 2
                        startBrightness = currentBrightness()
                        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                        startVolume = audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / max
                    }
                }
                val hgt = playerView.height.toFloat().coerceAtLeast(1f)
                when (gestureMode) {
                    1 -> {
                        val v = (startBrightness - totalY / hgt * 1.3f).coerceIn(0.02f, 1f)
                        setBrightness(v)
                        showHud("☀  ${(v * 100).roundToInt()}%")
                    }
                    2 -> {
                        val v = (startVolume - totalY / hgt * 1.3f).coerceIn(0f, 1f)
                        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                        audio.setStreamVolume(AudioManager.STREAM_MUSIC, (v * max).roundToInt(), 0)
                        showHud("🔊  ${(v * 100).roundToInt()}%")
                    }
                    3 -> {
                        val dur = p.duration
                        seekTarget = (seekStart + totalX / playerView.width * 90_000f).toLong().coerceIn(0L, dur)
                        showHud("${fmt(seekTarget)} / ${fmt(dur)}")
                    }
                }
                return true
            }
        })

        playerView.setOnTouchListener { _, ev ->
            gestures.onTouchEvent(ev)
            if (ev.action == MotionEvent.ACTION_UP || ev.action == MotionEvent.ACTION_CANCEL) {
                if (gestureMode == 3) player?.seekTo(seekTarget)
                gestureMode = 0
            }
            true
        }
    }

    // ---------- TV remote ----------

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val p = player
        if (p != null && event.action == KeyEvent.ACTION_DOWN) {
            when (event.keyCode) {
                KeyEvent.KEYCODE_CHANNEL_UP, KeyEvent.KEYCODE_PAGE_UP -> {
                    p.seekToNextMediaItem()
                    return true
                }
                KeyEvent.KEYCODE_CHANNEL_DOWN, KeyEvent.KEYCODE_PAGE_DOWN -> {
                    p.seekToPreviousMediaItem()
                    return true
                }
            }
            if (!playerView.isControllerFullyVisible) {
                when (event.keyCode) {
                    KeyEvent.KEYCODE_DPAD_LEFT -> {
                        p.seekTo((p.currentPosition - 10_000).coerceAtLeast(0))
                        return true
                    }
                    KeyEvent.KEYCODE_DPAD_RIGHT -> {
                        p.seekTo(p.currentPosition + 10_000)
                        return true
                    }
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    companion object {
        const val EXTRA_URL = "extra_url"
        const val EXTRA_SUB = "extra_sub"
        const val EXTRA_PLAYLIST = "extra_playlist"
        const val EXTRA_INDEX = "extra_index"
        private const val KEY_INDEX = "idx"
        private const val KEY_POS = "pos"
        private const val KEY_PLAY = "play"
    }
}
