package com.kaizen.stream

import android.annotation.SuppressLint
import android.app.PictureInPictureParams
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.Rational
import android.view.GestureDetector
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import io.github.anilbeesetti.nextlib.media3ext.ffdecoder.NextRenderersFactory
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

@OptIn(UnstableApi::class)
class PlayerActivity : AppCompatActivity() {

    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var errorText: TextView
    private lateinit var hudText: TextView
    private lateinit var titleText: TextView
    private lateinit var infoText: TextView
    private lateinit var controls: View
    private lateinit var loader: View
    private lateinit var playBtn: ImageView
    private lateinit var prevBtn: View
    private lateinit var nextBtn: View
    private lateinit var seekBar: SeekBar
    private lateinit var posText: TextView
    private lateinit var durText: TextView
    private lateinit var speedText: TextView
    private lateinit var aspectText: TextView
    private lateinit var unlockBtn: View
    private lateinit var audio: AudioManager
    private lateinit var gestures: GestureDetector

    private val handler = Handler(Looper.getMainLooper())
    private var controlsVisible = true
    private var locked = false
    private var scrubbing = false

    private var singleUrl = ""
    private var subUrl: String? = null
    private var playlist: List<Entry> = emptyList()
    private var resumeIndex = 0
    private var resumePosition = 0L
    private var resumePlaying = true

    private var resizeIdx = 0
    private val resizeModes = intArrayOf(
        AspectRatioFrameLayout.RESIZE_MODE_FIT,
        AspectRatioFrameLayout.RESIZE_MODE_FILL,
        AspectRatioFrameLayout.RESIZE_MODE_ZOOM
    )
    private val resizeNames = arrayOf("Fit", "Stretch", "Zoom")
    private val speeds = floatArrayOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f)

    // gesture state: 0 = none, -1 = ignored, 1 = brightness, 2 = volume, 3 = seek
    private var gestureMode = 0
    private var seekStart = 0L
    private var seekTarget = 0L
    private var startBrightness = 0.5f
    private var startVolume = 0f

    private val hideHud = Runnable { hudText.visibility = View.GONE }
    private val hideUnlock = Runnable { unlockBtn.visibility = View.GONE }
    private val hideRunnable = Runnable {
        if (player?.isPlaying == true && !scrubbing) hideControls()
    }
    private val tick = object : Runnable {
        override fun run() {
            updateProgress()
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)
        playerView = findViewById(R.id.playerView)
        errorText = findViewById(R.id.errorText)
        hudText = findViewById(R.id.hudText)
        titleText = findViewById(R.id.titleText)
        infoText = findViewById(R.id.infoText)
        controls = findViewById(R.id.controls)
        loader = findViewById(R.id.loader)
        playBtn = findViewById(R.id.playBtn)
        prevBtn = findViewById(R.id.prevBtn)
        nextBtn = findViewById(R.id.nextBtn)
        seekBar = findViewById(R.id.seekBar)
        posText = findViewById(R.id.posText)
        durText = findViewById(R.id.durText)
        speedText = findViewById(R.id.speedText)
        aspectText = findViewById(R.id.aspectText)
        unlockBtn = findViewById(R.id.unlockBtn)
        audio = getSystemService(AUDIO_SERVICE) as AudioManager

        if (intent.getBooleanExtra(EXTRA_PLAYLIST, false)) {
            playlist = PlaylistHolder.entries
            resumeIndex = intent.getIntExtra(EXTRA_INDEX, 0).coerceIn(0, (playlist.size - 1).coerceAtLeast(0))
        } else {
            singleUrl = intent.getStringExtra(EXTRA_URL) ?: intent.dataString ?: ""
            subUrl = intent.getStringExtra(EXTRA_SUB)
        }
        if (playlist.isEmpty() && singleUrl.isBlank()) {
            finish()
            return
        }

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        errorText.setOnClickListener { retry() }
        savedInstanceState?.let {
            resumeIndex = it.getInt(KEY_INDEX, resumeIndex)
            resumePosition = it.getLong(KEY_POS)
            resumePlaying = it.getBoolean(KEY_PLAY, true)
        }

        setupControls()
        setupGestures()
        hideSystemBars()
    }

    override fun onStart() {
        super.onStart()
        initPlayer()
        showControls()
        handler.post(tick)
    }

    override fun onStop() {
        super.onStop()
        handler.removeCallbacks(tick)
        handler.removeCallbacks(hideRunnable)
        releasePlayer()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        player?.let {
            resumeIndex = it.currentMediaItemIndex
            resumePosition = it.currentPosition
            resumePlaying = it.playWhenReady
        }
        outState.putInt(KEY_INDEX, resumeIndex)
        outState.putLong(KEY_POS, resumePosition)
        outState.putBoolean(KEY_PLAY, resumePlaying)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (Build.VERSION.SDK_INT >= 26 && player?.isPlaying == true) enterPip()
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        if (isInPictureInPictureMode) {
            controls.visibility = View.GONE
            unlockBtn.visibility = View.GONE
            hudText.visibility = View.GONE
        } else {
            if (locked) showUnlock() else showControls()
        }
    }

    private fun hideSystemBars() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            hide(WindowInsetsCompat.Type.systemBars())
        }
    }

    // ---------- control bar ----------

    private fun setupControls() {
        findViewById<View>(R.id.backBtn).setOnClickListener { finish() }
        val pipBtn = findViewById<View>(R.id.pipBtn)
        if (Build.VERSION.SDK_INT >= 26 &&
            packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)
        ) pipBtn.setOnClickListener { enterPip() }
        else pipBtn.visibility = View.GONE

        playBtn.setOnClickListener { togglePlay() }
        findViewById<View>(R.id.rewBtn).setOnClickListener { seekBy(-10_000); scheduleHide() }
        findViewById<View>(R.id.fwdBtn).setOnClickListener { seekBy(10_000); scheduleHide() }
        prevBtn.setOnClickListener { player?.seekToPreviousMediaItem(); scheduleHide() }
        nextBtn.setOnClickListener { player?.seekToNextMediaItem(); scheduleHide() }

        findViewById<View>(R.id.speedBtn).setOnClickListener { showSpeedDialog() }
        findViewById<View>(R.id.audioBtn).setOnClickListener { showTrackDialog(C.TRACK_TYPE_AUDIO, "Audio", false) }
        findViewById<View>(R.id.subBtn).setOnClickListener { showTrackDialog(C.TRACK_TYPE_TEXT, "Subtitles", true) }
        findViewById<View>(R.id.aspectBtn).setOnClickListener { cycleResize(); scheduleHide() }
        findViewById<View>(R.id.rotateBtn).setOnClickListener { rotate(); scheduleHide() }
        findViewById<View>(R.id.lockBtn).setOnClickListener { lock() }
        unlockBtn.setOnClickListener { unlock() }

        seekBar.keyProgressIncrement = 10_000
        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                posText.text = fmt(progress.toLong())
                if (!scrubbing) {
                    player?.seekTo(progress.toLong())
                    scheduleHide()
                }
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {
                scrubbing = true
                handler.removeCallbacks(hideRunnable)
            }

            override fun onStopTrackingTouch(sb: SeekBar?) {
                player?.seekTo((sb?.progress ?: 0).toLong())
                scrubbing = false
                scheduleHide()
            }
        })
    }

    private fun showControls() {
        if (locked) return
        controlsVisible = true
        controls.animate().cancel()
        controls.visibility = View.VISIBLE
        controls.animate().alpha(1f).setDuration(180).start()
        updatePlayIcon()
        updateNavButtons()
        updateProgress()
        if (!packageManager.hasSystemFeature(PackageManager.FEATURE_TOUCHSCREEN) && !playBtn.isFocused) {
            playBtn.requestFocus()
        }
        scheduleHide()
    }

    private fun hideControls() {
        controlsVisible = false
        handler.removeCallbacks(hideRunnable)
        controls.animate().cancel()
        controls.animate().alpha(0f).setDuration(180).withEndAction {
            if (!controlsVisible) controls.visibility = View.GONE
        }.start()
    }

    private fun scheduleHide() {
        handler.removeCallbacks(hideRunnable)
        handler.postDelayed(hideRunnable, 4000)
    }

    private fun togglePlay() {
        val p = player ?: return
        if (p.playbackState == Player.STATE_ENDED) {
            p.seekTo(0)
            p.play()
        } else if (p.playWhenReady) p.pause() else p.play()
        updatePlayIcon()
        scheduleHide()
    }

    private fun seekBy(deltaMs: Long) {
        val p = player ?: return
        val target = p.currentPosition + deltaMs
        val dur = p.duration
        p.seekTo(if (dur != C.TIME_UNSET) target.coerceIn(0L, dur) else target.coerceAtLeast(0L))
    }

    private fun updatePlayIcon() {
        val p = player
        val playing = p != null && p.playWhenReady && p.playbackState != Player.STATE_ENDED
        playBtn.setImageResource(if (playing) R.drawable.ic_pause else R.drawable.ic_play)
    }

    private fun updateNavButtons() {
        val multi = (player?.mediaItemCount ?: 0) > 1
        prevBtn.visibility = if (multi) View.VISIBLE else View.GONE
        nextBtn.visibility = if (multi) View.VISIBLE else View.GONE
    }

    private fun updateProgress() {
        val p = player ?: return
        if (!controlsVisible || scrubbing) return
        val dur = p.duration
        val live = dur == C.TIME_UNSET || p.isCurrentMediaItemLive
        if (live) {
            seekBar.visibility = View.INVISIBLE
            posText.text = fmt(p.currentPosition)
            durText.text = "LIVE"
        } else {
            val max = dur.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
            seekBar.visibility = View.VISIBLE
            seekBar.max = max
            seekBar.progress = p.currentPosition.coerceIn(0L, max.toLong()).toInt()
            seekBar.secondaryProgress = p.bufferedPosition.coerceIn(0L, max.toLong()).toInt()
            posText.text = fmt(p.currentPosition)
            durText.text = fmt(dur)
        }
    }

    // ---------- lock ----------

    private fun lock() {
        locked = true
        hideControls()
        showUnlock()
    }

    private fun unlock() {
        locked = false
        handler.removeCallbacks(hideUnlock)
        unlockBtn.visibility = View.GONE
        showControls()
    }

    private fun showUnlock() {
        unlockBtn.visibility = View.VISIBLE
        handler.removeCallbacks(hideUnlock)
        handler.postDelayed(hideUnlock, 2500)
    }

    // ---------- player ----------

    private fun buildItems(): List<MediaItem> {
        if (playlist.isNotEmpty()) {
            return playlist.map {
                MediaItem.Builder()
                    .setUri(it.url)
                    .setMediaMetadata(MediaMetadata.Builder().setTitle(it.title).build())
                    .build()
            }
        }
        val b = MediaItem.Builder()
            .setUri(singleUrl)
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle(Uri.decode(singleUrl.substringBefore('?').trimEnd('/').substringAfterLast('/')))
                    .build()
            )
        val sub = subUrl
        if (!sub.isNullOrBlank()) {
            val l = sub.substringBefore('?').lowercase()
            val mime = when {
                l.endsWith(".vtt") -> MimeTypes.TEXT_VTT
                l.endsWith(".ass") || l.endsWith(".ssa") -> MimeTypes.TEXT_SSA
                l.endsWith(".ttml") || l.endsWith(".xml") || l.endsWith(".dfxp") -> MimeTypes.APPLICATION_TTML
                else -> MimeTypes.APPLICATION_SUBRIP
            }
            b.setSubtitleConfigurations(
                listOf(
                    MediaItem.SubtitleConfiguration.Builder(Uri.parse(sub))
                        .setMimeType(mime)
                        .setLanguage("und")
                        .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                        .build()
                )
            )
        }
        return listOf(b.build())
    }

    private fun initPlayer() {
        if (player != null) return

        val http = DefaultHttpDataSource.Factory()
            .setUserAgent("Mozilla/5.0 (Linux; Android 13) KaizenStream/3.0")
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15_000)
            .setReadTimeoutMs(15_000)

        // Hardware decoders first; FFmpeg software decoders as fallback (DTS, TrueHD, AC3...)
        val renderers = NextRenderersFactory(this)
        renderers.setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
        renderers.setEnableDecoderFallback(true)

        val p = ExoPlayer.Builder(this, renderers)
            .setMediaSourceFactory(DefaultMediaSourceFactory(DefaultDataSource.Factory(this, http)))
            .setSeekBackIncrementMs(10_000)
            .setSeekForwardIncrementMs(10_000)
            .build()

        p.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                loader.visibility = View.GONE
                var msg = "Can't play this\n\n${error.errorCodeName}\n" +
                    (error.cause?.message ?: error.message ?: "") + "\n\nTap to retry"
                if (playlist.isNotEmpty()) msg += " • or press next to skip"
                errorText.text = msg
                errorText.visibility = View.VISIBLE
                showControls()
            }

            override fun onPlaybackStateChanged(state: Int) {
                loader.visibility = if (state == Player.STATE_BUFFERING) View.VISIBLE else View.GONE
                if (state == Player.STATE_READY) errorText.visibility = View.GONE
                updatePlayIcon()
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                updatePlayIcon()
                if (isPlaying) { if (controlsVisible) scheduleHide() }
                else handler.removeCallbacks(hideRunnable)
            }

            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
                updatePlayIcon()
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                titleText.text = mediaItem?.mediaMetadata?.title ?: ""
                errorText.visibility = View.GONE
                updateNavButtons()
                player?.let { if (it.playbackState == Player.STATE_IDLE) it.prepare() }
            }

            override fun onVideoSizeChanged(videoSize: VideoSize) = refreshInfo()
            override fun onTracksChanged(tracks: Tracks) = refreshInfo()
        })

        playerView.player = p
        p.setMediaItems(buildItems(), resumeIndex, if (resumePosition > 0) resumePosition else C.TIME_UNSET)
        p.playWhenReady = resumePlaying
        p.prepare()
        player = p
        speedText.text = speedLabel(p.playbackParameters.speed)
    }

    private fun releasePlayer() {
        player?.let {
            resumeIndex = it.currentMediaItemIndex
            resumePosition = it.currentPosition
            resumePlaying = it.playWhenReady
            playerView.player = null
            it.release()
        }
        player = null
    }

    private fun retry() {
        errorText.visibility = View.GONE
        player?.let {
            it.prepare()
            it.play()
        }
    }

    private fun refreshInfo() {
        val p = player ?: return
        val parts = ArrayList<String>()
        val vs = p.videoSize
        if (vs.height > 0) parts.add("${vs.height}p")
        codecName(p.videoFormat?.sampleMimeType)?.let { parts.add(it) }
        codecName(p.audioFormat?.sampleMimeType)?.let { parts.add(it) }
        infoText.text = parts.joinToString("  •  ")
    }

    // ---------- dialogs ----------

    private fun choose(title: String, labels: Array<String>, checked: Int, onPick: (Int) -> Unit) {
        handler.removeCallbacks(hideRunnable)
        MaterialAlertDialogBuilder(this)
            .setTitle(title)
            .setSingleChoiceItems(labels, checked) { d, which ->
                onPick(which)
                d.dismiss()
            }
            .setNegativeButton("Close", null)
            .setOnDismissListener { if (controlsVisible) scheduleHide() }
            .show()
    }

    private fun speedLabel(v: Float): String = if (v == 1f) "1x" else "${v}x"

    private fun showSpeedDialog() {
        val p = player ?: return
        val labels = speeds.map { if (it == 1f) "Normal" else "${it}x" }.toTypedArray()
        var checked = speeds.indexOfFirst { abs(it - p.playbackParameters.speed) < 0.01f }
        if (checked < 0) checked = 2
        choose("Playback speed", labels, checked) { which ->
            p.setPlaybackSpeed(speeds[which])
            speedText.text = speedLabel(speeds[which])
        }
    }

    private fun showTrackDialog(type: Int, title: String, allowOff: Boolean) {
        val p = player ?: return
        val entries = ArrayList<Pair<Tracks.Group?, Int>>()
        val labels = ArrayList<String>()
        var checked = 0
        val disabled = p.trackSelectionParameters.disabledTrackTypes.contains(type)
        if (allowOff) {
            entries.add(Pair(null, -1))
            labels.add("Off")
            if (disabled) checked = 0
        }
        for (g in p.currentTracks.groups) {
            if (g.type != type) continue
            for (i in 0 until g.length) {
                if (!g.isTrackSupported(i)) continue
                entries.add(Pair(g, i))
                labels.add(trackLabel(g.getTrackFormat(i), labels.size + 1, type == C.TRACK_TYPE_AUDIO))
                if (g.isTrackSelected(i) && !disabled) checked = entries.size - 1
            }
        }
        if (entries.size <= (if (allowOff) 1 else 0)) {
            Toast.makeText(this, "No $title tracks in this video", Toast.LENGTH_SHORT).show()
            return
        }
        choose(title, labels.toTypedArray(), checked) { which ->
            val (g, i) = entries[which]
            val b = p.trackSelectionParameters.buildUpon()
            if (g == null) {
                b.setTrackTypeDisabled(type, true)
            } else {
                b.setTrackTypeDisabled(type, false)
                b.setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, i))
            }
            p.trackSelectionParameters = b.build()
        }
    }

    private fun codecName(mime: String?): String? = when (mime) {
        MimeTypes.VIDEO_H265 -> "HEVC"
        MimeTypes.VIDEO_H264 -> "H.264"
        MimeTypes.VIDEO_AV1 -> "AV1"
        MimeTypes.VIDEO_VP9 -> "VP9"
        MimeTypes.VIDEO_VP8 -> "VP8"
        MimeTypes.AUDIO_AC3 -> "Dolby Digital"
        MimeTypes.AUDIO_E_AC3, MimeTypes.AUDIO_E_AC3_JOC -> "Dolby Digital+"
        MimeTypes.AUDIO_TRUEHD -> "TrueHD"
        MimeTypes.AUDIO_DTS, MimeTypes.AUDIO_DTS_HD -> "DTS"
        MimeTypes.AUDIO_AAC -> "AAC"
        MimeTypes.AUDIO_OPUS -> "Opus"
        MimeTypes.AUDIO_FLAC -> "FLAC"
        MimeTypes.AUDIO_MPEG -> "MP3"
        MimeTypes.AUDIO_VORBIS -> "Vorbis"
        else -> null
    }

    private fun channelLabel(n: Int): String? = when (n) {
        1 -> "Mono"
        2 -> "Stereo"
        6 -> "5.1"
        8 -> "7.1"
        Format.NO_VALUE, 0 -> null
        else -> "${n}ch"
    }

    private fun trackLabel(f: Format, n: Int, isAudio: Boolean): String {
        val lang = f.language?.takeIf { it != "und" }?.let {
            Locale.forLanguageTag(it).displayLanguage.ifBlank { it }.replaceFirstChar { c -> c.uppercase() }
        }
        val parts = ArrayList<String>()
        parts.add(f.label ?: lang ?: "Track $n")
        if (isAudio) {
            codecName(f.sampleMimeType)?.let { parts.add(it) }
            channelLabel(f.channelCount)?.let { parts.add(it) }
        }
        return parts.joinToString("  •  ")
    }

    // ---------- aspect ratio / rotate / PiP ----------

    private fun cycleResize() {
        resizeIdx = (resizeIdx + 1) % resizeModes.size
        playerView.resizeMode = resizeModes[resizeIdx]
        aspectText.text = resizeNames[resizeIdx]
        showHud(resizeNames[resizeIdx])
    }

    private fun rotate() {
        val land = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        requestedOrientation = if (land) ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        else ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
    }

    private fun enterPip() {
        if (Build.VERSION.SDK_INT < 26 ||
            !packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)
        ) {
            Toast.makeText(this, "Picture-in-picture isn't supported here", Toast.LENGTH_SHORT).show()
            return
        }
        val vs = player?.videoSize
        var r = if (vs != null && vs.width > 0 && vs.height > 0) vs.width.toFloat() / vs.height else 16f / 9f
        r = r.coerceIn(0.45f, 2.3f)
        try {
            enterPictureInPictureMode(
                PictureInPictureParams.Builder()
                    .setAspectRatio(Rational((r * 1000).toInt(), 1000))
                    .build()
            )
        } catch (e: Exception) {
            Toast.makeText(this, "Turn on picture-in-picture for this app in Settings", Toast.LENGTH_LONG).show()
        }
    }

    // ---------- touch gestures ----------

    private fun showHud(text: String) {
        hudText.text = text
        hudText.visibility = View.VISIBLE
        hudText.removeCallbacks(hideHud)
        hudText.postDelayed(hideHud, 900)
    }

    private fun fmt(ms: Long): String {
        val s = (ms / 1000).coerceAtLeast(0)
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) String.format("%d:%02d:%02d", h, m, sec) else String.format("%02d:%02d", m, sec)
    }

    private fun currentBrightness(): Float {
        val b = window.attributes.screenBrightness
        if (b >= 0f) return b
        return try {
            Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS) / 255f
        } catch (e: Exception) {
            0.5f
        }
    }

    private fun setBrightness(v: Float) {
        val lp = window.attributes
        lp.screenBrightness = v
        window.attributes = lp
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupGestures() {
        gestures = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (controlsVisible) hideControls() else showControls()
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                val p = player ?: return true
                val w = playerView.width.toFloat()
                when {
                    e.x < w / 3f -> {
                        seekBy(-10_000)
                        showHud("⏪  10s")
                    }
                    e.x > w * 2f / 3f -> {
                        seekBy(10_000)
                        showHud("10s  ⏩")
                    }
                    else -> togglePlay()
                }
                return true
            }

            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
                val start = e1 ?: return false
                val p = player ?: return false
                val totalX = e2.x - start.x
                val totalY = e2.y - start.y
                if (gestureMode == 0) {
                    if (abs(totalX) > abs(totalY)) {
                        gestureMode = if (p.isCurrentMediaItemSeekable && p.duration != C.TIME_UNSET) 3 else -1
                        seekStart = p.currentPosition
                    } else {
                        gestureMode = if (start.x < playerView.width / 2f) 1 else 2
                        startBrightness = currentBrightness()
                        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                        startVolume = audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / max
                    }
                }
                val hgt = playerView.height.toFloat().coerceAtLeast(1f)
                when (gestureMode) {
                    1 -> {
                        val v = (startBrightness - totalY / hgt * 1.3f).coerceIn(0.02f, 1f)
                        setBrightness(v)
                        showHud("☀  ${(v * 100).roundToInt()}%")
                    }
                    2 -> {
                        val v = (startVolume - totalY / hgt * 1.3f).coerceIn(0f, 1f)
                        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                        audio.setStreamVolume(AudioManager.STREAM_MUSIC, (v * max).roundToInt(), 0)
                        showHud("🔊  ${(v * 100).roundToInt()}%")
                    }
                    3 -> {
                        val dur = p.duration
                        seekTarget = (seekStart + totalX / playerView.width * 90_000f).toLong().coerceIn(0L, dur)
                        showHud("${fmt(seekTarget)} / ${fmt(dur)}")
                    }
                }
                return true
            }
        })

        playerView.setOnTouchListener { _, ev ->
            if (locked) {
                if (ev.action == MotionEvent.ACTION_UP) showUnlock()
                return@setOnTouchListener true
            }
            gestures.onTouchEvent(ev)
            if (ev.action == MotionEvent.ACTION_UP || ev.action == MotionEvent.ACTION_CANCEL) {
                if (gestureMode == 3) player?.seekTo(seekTarget)
                gestureMode = 0
            }
            true
        }
    }

    // ---------- TV remote / media keys ----------

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val p = player
        if (p != null && event.action == KeyEvent.ACTION_DOWN) {
            when (event.keyCode) {
                KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> { togglePlay(); return true }
                KeyEvent.KEYCODE_MEDIA_PLAY -> { p.play(); return true }
                KeyEvent.KEYCODE_MEDIA_PAUSE -> { p.pause(); return true }
                KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> { seekBy(10_000); return true }
                KeyEvent.KEYCODE_MEDIA_REWIND -> { seekBy(-10_000); return true }
                KeyEvent.KEYCODE_MEDIA_NEXT, KeyEvent.KEYCODE_CHANNEL_UP, KeyEvent.KEYCODE_PAGE_UP -> {
                    p.seekToNextMediaItem()
                    return true
                }
                KeyEvent.KEYCODE_MEDIA_PREVIOUS, KeyEvent.KEYCODE_CHANNEL_DOWN, KeyEvent.KEYCODE_PAGE_DOWN -> {
                    p.seekToPreviousMediaItem()
                    return true
                }
            }
            if (locked) return true
            if (!controlsVisible) {
                when (event.keyCode) {
                    KeyEvent.KEYCODE_DPAD_LEFT -> { seekBy(-10_000); return true }
                    KeyEvent.KEYCODE_DPAD_RIGHT -> { seekBy(10_000); return true }
                    KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER,
                    KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN -> {
                        showControls()
                        return true
                    }
                }
            } else {
                scheduleHide()
            }
        }
        return super.dispatchKeyEvent(event)
    }

    companion object {
        const val EXTRA_URL = "extra_url"
        const val EXTRA_SUB = "extra_sub"
        const val EXTRA_PLAYLIST = "extra_playlist"
        const val EXTRA_INDEX = "extra_index"
        private const val KEY_INDEX = "idx"
        private const val KEY_POS = "pos"
        private const val KEY_PLAY = "play"
    }
}
