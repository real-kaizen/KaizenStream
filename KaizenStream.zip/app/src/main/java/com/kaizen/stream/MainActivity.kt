package com.kaizen.stream

import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var urlInput: EditText
    private lateinit var subInput: EditText
    private lateinit var emptyHint: TextView
    private lateinit var list: ListView
    private lateinit var adapter: RecentAdapter
    private lateinit var store: HistoryStore
    private var lastAutoPasted: String? = null

    private val pickPlaylist =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) loadPlaylistFromFile(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        store = HistoryStore(this)
        list = findViewById(R.id.list)
        val header = layoutInflater.inflate(R.layout.header_main, list, false)
        list.addHeaderView(header, null, false)

        val spacer = header.findViewById<View>(R.id.topSpacer)
        val lp = spacer.layoutParams
        lp.height = BlackHoleView.holeBottomPx(this)
        spacer.layoutParams = lp

        urlInput = header.findViewById(R.id.urlInput)
        subInput = header.findViewById(R.id.subInput)
        emptyHint = header.findViewById(R.id.emptyHint)

        adapter = RecentAdapter()
        list.adapter = adapter

        header.findViewById<View>(R.id.playButton).setOnClickListener { play(urlInput.text.toString()) }
        header.findViewById<View>(R.id.pasteButton).setOnClickListener {
            val clip = clipboardUrl()
            if (clip != null) urlInput.setText(clip)
            else toast("No web link in clipboard")
        }
        header.findViewById<View>(R.id.playlistButton).setOnClickListener {
            val url = normalize(urlInput.text.toString())
            if (url == null) toast("Paste a playlist link first") else openPlaylistUrl(url)
        }
        header.findViewById<View>(R.id.fileButton).setOnClickListener {
            pickPlaylist.launch(arrayOf("*/*"))
        }
        header.findViewById<View>(R.id.clearButton).setOnClickListener {
            store.clear()
            refresh()
        }
        urlInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO) {
                play(urlInput.text.toString())
                true
            } else false
        }
        list.setOnItemClickListener { parent, _, position, _ ->
            val s = parent.getItemAtPosition(position) as? String ?: return@setOnItemClickListener
            if (s.startsWith("PL|")) openPlaylistUrl(s.removePrefix("PL|")) else play(s)
        }
        list.setOnItemLongClickListener { parent, _, position, _ ->
            val s = parent.getItemAtPosition(position) as? String
            if (s != null) {
                store.remove(s)
                refresh()
                toast("Removed")
            }
            true
        }
        refresh()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && urlInput.text.isNullOrBlank()) {
            val clip = clipboardUrl()
            if (clip != null && clip != lastAutoPasted) {
                lastAutoPasted = clip
                urlInput.setText(clip)
            }
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun clipboardUrl(): String? {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = cm.primaryClip ?: return null
        if (clip.itemCount == 0) return null
        val text = clip.getItemAt(0).coerceToText(this)?.toString()?.trim() ?: return null
        return if (text.startsWith("http://", true) || text.startsWith("https://", true)) text else null
    }

    private fun refresh() {
        adapter.clear()
        adapter.addAll(store.getAll())
        adapter.notifyDataSetChanged()
        emptyHint.visibility = if (adapter.isEmpty) View.VISIBLE else View.GONE
    }

    private fun normalize(raw: String): String? {
        val u = raw.trim()
        if (u.isEmpty()) return null
        return if (u.startsWith("http://", true) || u.startsWith("https://", true)) u else "http://$u"
    }

    private fun play(raw: String) {
        val url = normalize(raw)
        if (url == null) {
            toast("Paste a video link first")
            return
        }
        val path = url.substringBefore('?').lowercase()
        if (path.endsWith(".m3u")) {
            openPlaylistUrl(url)
            return
        }
        startPlayer(url, normalize(subInput.text.toString()))
    }

    private fun startPlayer(url: String, sub: String?) {
        store.add(url)
        refresh()
        val i = Intent(this, PlayerActivity::class.java).putExtra(PlayerActivity.EXTRA_URL, url)
        if (sub != null) i.putExtra(PlayerActivity.EXTRA_SUB, sub)
        startActivity(i)
    }

    private fun openPlaylistUrl(url: String) {
        toast("Loading playlist…")
        Thread {
            try {
                val text = Net.fetchText(url)
                if (PlaylistParser.looksLikeHls(text)) {
                    runOnUiThread { if (!isFinishing) startPlayer(url, null) }
                    return@Thread
                }
                val entries = PlaylistParser.parse(text, url)
                val name = url.substringBefore('?').substringAfterLast('/').ifEmpty { "Playlist" }
                runOnUiThread { if (!isFinishing) showPlaylist(name, entries, url) }
            } catch (e: Exception) {
                runOnUiThread { toast("Can't load playlist: ${e.message ?: "error"}") }
            }
        }.start()
    }

    private fun loadPlaylistFromFile(uri: Uri) {
        toast("Reading playlist…")
        Thread {
            try {
                val text = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
                val entries = PlaylistParser.parse(text, null)
                val name = uri.lastPathSegment?.substringAfterLast('/') ?: "Playlist"
                runOnUiThread { if (!isFinishing) showPlaylist(name, entries, null) }
            } catch (e: Exception) {
                runOnUiThread { toast("Can't read that file") }
            }
        }.start()
    }

    private fun showPlaylist(title: String, entries: List<Entry>, saveUrl: String?) {
        if (entries.isEmpty()) {
            toast("No playable links found in this playlist")
            return
        }
        if (saveUrl != null) {
            store.add("PL|$saveUrl")
            refresh()
        }
        PlaylistHolder.title = title
        PlaylistHolder.entries = entries
        startActivity(Intent(this, PlaylistActivity::class.java))
    }

    private inner class RecentAdapter : ArrayAdapter<String>(this@MainActivity, R.layout.item_recent) {
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val v = super.getView(position, convertView, parent) as TextView
            val s = getItem(position) ?: ""
            v.text = if (s.startsWith("PL|")) "☰  " + s.removePrefix("PL|") else "▶  $s"
            return v
        }
    }
}
