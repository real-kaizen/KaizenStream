package com.kaizen.stream

import android.animation.ValueAnimator
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.view.animation.LinearInterpolator
import android.view.inputmethod.EditorInfo
import android.widget.AbsListView
import android.widget.EditText
import android.widget.ListView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var urlInput: EditText
    private lateinit var subInput: EditText
    private lateinit var subField: View
    private lateinit var emptyHint: View
    private lateinit var list: ListView
    private lateinit var hole: BlackHoleView
    private lateinit var lib: Library
    private lateinit var adapter: LibAdapter
    private var lastAutoPasted: String? = null
    private var swallowing = false

    private val pickPlaylist =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) loadPlaylistFromFile(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        lib = Library(this)
        hole = findViewById(R.id.hole)
        list = findViewById(R.id.list)
        val header = layoutInflater.inflate(R.layout.header_main, list, false) as ViewGroup
        list.addHeaderView(header, null, false)

        urlInput = header.findViewById(R.id.urlInput)
        subInput = header.findViewById(R.id.subInput)
        subField = header.findViewById(R.id.subField)
        emptyHint = header.findViewById(R.id.emptyHint)

        adapter = LibAdapter(this, { item, fromStart -> openItem(item, fromStart) }, { refresh() })
        list.adapter = adapter

        list.setOnScrollListener(object : AbsListView.OnScrollListener {
            override fun onScrollStateChanged(view: AbsListView?, scrollState: Int) {}
            override fun onScroll(view: AbsListView?, first: Int, visible: Int, total: Int) {
                val c = view?.getChildAt(0)
                hole.parallax = if (first == 0 && c != null) (-c.top).toFloat() else 3000f
            }
        })

        header.findViewById<View>(R.id.pasteButton).setOnClickListener {
            val clip = clipboardUrl()
            if (clip != null) urlInput.setText(clip) else toast("No web link in clipboard")
        }
        header.findViewById<View>(R.id.subToggle).setOnClickListener {
            subField.visibility = if (subField.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
        header.findViewById<View>(R.id.playButton).setOnClickListener { play(urlInput.text.toString()) }
        header.findViewById<View>(R.id.autoButton).setOnClickListener {
            val clip = clipboardUrl()
            if (clip != null) {
                urlInput.setText(clip)
                play(clip)
            } else toast("No web link in clipboard")
        }
        header.findViewById<View>(R.id.playlistButton).setOnClickListener {
            val url = normalize(urlInput.text.toString())
            if (url == null) toast("Paste a playlist link first") else openPlaylist(url)
        }
        header.findViewById<View>(R.id.fileButton).setOnClickListener {
            pickPlaylist.launch(arrayOf("*/*"))
        }
        header.findViewById<View>(R.id.viewAll).setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }
        findViewById<View>(R.id.settingsBtn).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        urlInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO) {
                play(urlInput.text.toString())
                true
            } else false
        }
        list.setOnItemClickListener { parent, _, position, _ ->
            val item = parent.getItemAtPosition(position) as? LibItem ?: return@setOnItemClickListener
            openItem(item, false)
        }
        list.setOnItemLongClickListener { parent, view, position, _ ->
            val item = parent.getItemAtPosition(position) as? LibItem
            if (item != null) {
                RowMenu.show(this, view, item, { fromStart -> openItem(item, fromStart) }, { refresh() })
            }
            true
        }

        BottomNav.setup(this, R.id.navHome)
    }

    override fun onResume() {
        super.onResume()
        swallowing = false
        hole.reset()
        list.alpha = 1f
        list.scaleX = 1f
        list.scaleY = 1f
        refresh()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && urlInput.text.isNullOrBlank()) {
            val clip = clipboardUrl()
            if (clip != null && clip != lastAutoPasted) {
                lastAutoPasted = clip
                urlInput.setText(clip)
            }
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun clipboardUrl(): String? {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = cm.primaryClip ?: return null
        if (clip.itemCount == 0) return null
        val text = clip.getItemAt(0).coerceToText(this)?.toString()?.trim() ?: return null
        return if (text.startsWith("http://", true) || text.startsWith("https://", true)) text else null
    }

    private fun refresh() {
        val items = lib.all().take(5)
        adapter.clear()
        adapter.addAll(items)
        adapter.notifyDataSetChanged()
        emptyHint.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun normalize(raw: String): String? {
        val u = raw.trim()
        if (u.isEmpty()) return null
        return if (u.startsWith("http://", true) || u.startsWith("https://", true)) u else "http://$u"
    }

    /** Zoom the black hole over the screen, then open the next screen. */
    private fun launch(intent: Intent) {
        if (swallowing) return
        swallowing = true
        hole.swallow({ p ->
            list.alpha = 1f - p
            list.scaleX = 1f - 0.12f * p
            list.scaleY = 1f - 0.12f * p
        }) {
            startActivity(intent)
            @Suppress("DEPRECATION")
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        }
    }

    private fun openItem(item: LibItem, fromStart: Boolean) {
        Launcher.open(this, item, fromStart) { launch(it) }
    }

    private fun play(raw: String) {
        val url = normalize(raw)
        if (url == null) {
            toast("Paste a video link first")
            return
        }
        if (url.substringBefore('?').lowercase().endsWith(".m3u")) {
            openPlaylist(url)
            return
        }
        launch(Launcher.playIntent(this, url, normalize(subInput.text.toString()), false))
    }

    private fun openPlaylist(url: String) {
        Launcher.openPlaylistUrl(this, url, false) { launch(it) }
    }

    private fun loadPlaylistFromFile(uri: Uri) {
        toast("Reading playlist…")
        Thread {
            try {
                val text = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
                val entries = PlaylistParser.parse(text, null)
                val name = uri.lastPathSegment?.substringAfterLast('/') ?: "Playlist"
                runOnUiThread {
                    if (isFinishing) return@runOnUiThread
                    if (entries.isEmpty()) {
                        toast("No playable links found in this file")
                    } else {
                        PlaylistHolder.title = name
                        PlaylistHolder.entries = entries
                        launch(Intent(this, PlaylistActivity::class.java))
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { toast("Can't read that file") }
            }
        }.start()
    }
}
