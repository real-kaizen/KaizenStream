package com.kaizen.stream

import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.inputmethod.EditorInfo
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var urlInput: EditText
    private lateinit var list: ListView
    private lateinit var adapter: ArrayAdapter<String>
    private lateinit var store: HistoryStore
    private var lastAutoPasted: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        store = HistoryStore(this)
        urlInput = findViewById(R.id.urlInput)
        list = findViewById(R.id.list)
        adapter = ArrayAdapter(this, R.layout.item_recent, mutableListOf<String>())
        list.adapter = adapter
        list.emptyView = findViewById<TextView>(R.id.emptyView)

        findViewById<android.view.View>(R.id.playButton).setOnClickListener {
            play(urlInput.text.toString())
        }
        findViewById<android.view.View>(R.id.pasteButton).setOnClickListener {
            val clip = clipboardUrl()
            if (clip != null) urlInput.setText(clip)
            else Toast.makeText(this, "No web link in clipboard", Toast.LENGTH_SHORT).show()
        }
        findViewById<android.view.View>(R.id.clearButton).setOnClickListener {
            store.clear()
            refresh()
        }
        urlInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO) {
                play(urlInput.text.toString())
                true
            } else false
        }
        list.setOnItemClickListener { _, _, position, _ ->
            adapter.getItem(position)?.let { play(it) }
        }
        list.setOnItemLongClickListener { _, _, position, _ ->
            adapter.getItem(position)?.let {
                store.remove(it)
                refresh()
                Toast.makeText(this, "Removed", Toast.LENGTH_SHORT).show()
            }
            true
        }
        refresh()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && urlInput.text.isNullOrBlank()) {
            val clip = clipboardUrl()
            if (clip != null && clip != lastAutoPasted) {
                lastAutoPasted = clip
                urlInput.setText(clip)
            }
        }
    }

    private fun clipboardUrl(): String? {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = cm.primaryClip ?: return null
        if (clip.itemCount == 0) return null
        val text = clip.getItemAt(0).coerceToText(this)?.toString()?.trim() ?: return null
        return if (text.startsWith("http://", true) || text.startsWith("https://", true)) text else null
    }

    private fun refresh() {
        adapter.clear()
        adapter.addAll(store.getAll())
        adapter.notifyDataSetChanged()
    }

    private fun play(raw: String) {
        var url = raw.trim()
        if (url.isEmpty()) {
            Toast.makeText(this, "Paste a video link first", Toast.LENGTH_SHORT).show()
            return
        }
        if (!url.startsWith("http://", true) && !url.startsWith("https://", true)) {
            url = "http://$url"
        }
        store.add(url)
        refresh()
        startActivity(Intent(this, PlayerActivity::class.java).putExtra(PlayerActivity.EXTRA_URL, url))
    }
}
