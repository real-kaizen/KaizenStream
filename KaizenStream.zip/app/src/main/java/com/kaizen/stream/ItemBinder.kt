package com.kaizen.stream

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.PopupMenu
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast

/** Fills the list row used by Recently Played, History and playlists. */
object ItemBinder {

    private fun letter(s: String): String =
        s.firstOrNull { it.isLetterOrDigit() }?.uppercase() ?: "•"

    fun bindLib(v: View, item: LibItem) {
        v.findViewById<TextView>(R.id.itemIcon).text = if (item.playlist) "≡" else letter(item.title)
        v.findViewById<TextView>(R.id.itemTitle).text = item.title
        v.findViewById<TextView>(R.id.itemSub).text = item.domain
        val status = v.findViewById<TextView>(R.id.itemStatus)
        status.visibility = View.VISIBLE
        status.text = when {
            item.playlist -> "Playlist"
            item.pos > 0 && item.dur > 0 -> "Paused  •  ${fmtTime(item.pos)} / ${fmtTime(item.dur)}"
            item.dur > 0 -> "Watched  •  ${fmtTime(item.dur)}"
            else -> "Not played yet"
        }
        val bar = v.findViewById<ProgressBar>(R.id.itemProgress)
        if (!item.playlist && item.pos > 0 && item.dur > 0) {
            bar.visibility = View.VISIBLE
            bar.progress = item.progress
        } else {
            bar.visibility = View.GONE
        }
        v.findViewById<View>(R.id.itemMenu).visibility = View.VISIBLE
    }

    fun bindEntry(v: View, e: Entry) {
        v.findViewById<TextView>(R.id.itemIcon).text = letter(e.title)
        v.findViewById<TextView>(R.id.itemTitle).text = e.title
        v.findViewById<TextView>(R.id.itemSub).text = domainOf(e.url)
        v.findViewById<View>(R.id.itemStatus).visibility = View.GONE
        v.findViewById<View>(R.id.itemProgress).visibility = View.GONE
        v.findViewById<View>(R.id.itemMenu).visibility = View.GONE
    }
}

object RowMenu {
    fun show(
        a: Activity,
        anchor: View,
        item: LibItem,
        onPlay: (Boolean) -> Unit,
        onChanged: () -> Unit
    ) {
        val m = PopupMenu(a, anchor)
        if (!item.playlist && item.pos > 0) m.menu.add(0, 1, 0, "Resume")
        m.menu.add(0, 2, 1, if (item.playlist) "Open playlist" else "Play from start")
        m.menu.add(0, 3, 2, "Copy link")
        m.menu.add(0, 4, 3, "Remove from history")
        m.setOnMenuItemClickListener { mi ->
            when (mi.itemId) {
                1 -> onPlay(false)
                2 -> onPlay(true)
                3 -> {
                    val cm = a.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("link", item.url))
                    Toast.makeText(a, "Link copied", Toast.LENGTH_SHORT).show()
                }
                4 -> {
                    Library(a).remove(item.url)
                    onChanged()
                }
            }
            true
        }
        m.show()
    }
}

class LibAdapter(
    private val act: Activity,
    private val onPlay: (LibItem, Boolean) -> Unit,
    private val onChanged: () -> Unit
) : ArrayAdapter<LibItem>(act, R.layout.item_recent) {
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val v = convertView ?: LayoutInflater.from(act).inflate(R.layout.item_recent, parent, false)
        val item = getItem(position) ?: return v
        ItemBinder.bindLib(v, item)
        v.findViewById<View>(R.id.itemMenu).setOnClickListener { anchor ->
            RowMenu.show(act, anchor, item, { fromStart -> onPlay(item, fromStart) }, onChanged)
        }
        return v
    }
}
