package com.kaizen.stream

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.view.View
import android.widget.TextView

/** Fills the two-line list row (coloured letter icon, title, subtitle). */
object ItemBinder {

    private val palettes = arrayOf(
        intArrayOf(Color.parseColor("#6E8BFF"), Color.parseColor("#3D5AFE")),
        intArrayOf(Color.parseColor("#4FC3F7"), Color.parseColor("#3D5AFE")),
        intArrayOf(Color.parseColor("#8C9EFF"), Color.parseColor("#5C6BC0")),
        intArrayOf(Color.parseColor("#26C6DA"), Color.parseColor("#3D5AFE"))
    )

    private fun host(url: String): String =
        try {
            Uri.parse(url).host?.removePrefix("www.") ?: url
        } catch (e: Exception) {
            url
        }

    private fun set(v: View, letter: String, title: String, sub: String, seed: Int) {
        val icon = v.findViewById<TextView>(R.id.itemIcon)
        icon.text = letter
        val g = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            palettes[(seed and 0x7fffffff) % palettes.size]
        )
        g.shape = GradientDrawable.OVAL
        icon.background = g
        v.findViewById<TextView>(R.id.itemTitle).text = title
        v.findViewById<TextView>(R.id.itemSub).text = sub
    }

    fun bindLink(v: View, url: String) {
        val h = host(url)
        val name = Uri.decode(url.substringBefore('?').trimEnd('/').substringAfterLast('/'))
        val title = if (name.isBlank() || name == h) h else name
        val letter = h.firstOrNull { it.isLetterOrDigit() }?.uppercase() ?: "▶"
        set(v, letter, title, url, h.hashCode())
    }

    fun bindPlaylist(v: View, url: String) {
        val name = url.substringBefore('?').trimEnd('/').substringAfterLast('/').ifBlank { host(url) }
        set(v, "☰", Uri.decode(name), "Playlist  •  " + host(url), url.hashCode())
    }

    fun bindEntry(v: View, e: Entry) {
        val letter = e.title.firstOrNull { it.isLetterOrDigit() }?.uppercase() ?: "▶"
        set(v, letter, e.title, host(e.url), e.title.hashCode())
    }
}
