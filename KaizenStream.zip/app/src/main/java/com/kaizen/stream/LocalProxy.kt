package com.kaizen.stream

import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.URL
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.Executors
import java.util.concurrent.Future
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Local read-ahead proxy ("smart network"). VLC plays from http://127.0.0.1:<port>, while this
 * class downloads the real link with Java's HTTP stack (the same kind of loader ExoPlayer uses)
 * into a ~32 MB read-ahead queue. Network hiccups never reach the player, and Range requests
 * (seeking) are passed through when the server supports them.
 */
class LocalProxy(private val upstream: String) {

    private var server: ServerSocket? = null
    private val pool = Executors.newCachedThreadPool()

    @Volatile
    private var running = false
    private var rangeOk = false
    private var total = -1L
    private var contentType = "application/octet-stream"

    /** Last known state of the upstream server, shown on the loading card. */
    @Volatile
    var status: String = ""

    val localUrl: String
        get() = "http://127.0.0.1:${server?.localPort ?: 0}/stream"

    /** Blocking: checks the server, then starts listening. Call from a background thread. */
    fun start(): Boolean {
        if (!probe()) return false
        val s = ServerSocket(0, 16, InetAddress.getByName("127.0.0.1"))
        server = s
        running = true
        pool.execute { acceptLoop(s) }
        return true
    }

    fun stop() {
        running = false
        try {
            server?.close()
        } catch (e: Exception) {
        }
        pool.shutdownNow()
    }

    private fun open(start: Long, end: Long, ranged: Boolean): HttpURLConnection {
        val c = URL(upstream).openConnection() as HttpURLConnection
        c.connectTimeout = 15_000
        c.readTimeout = 30_000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", UA)
        c.setRequestProperty("Accept-Encoding", "identity")
        if (ranged) c.setRequestProperty("Range", "bytes=$start-$end")
        return c
    }

    private fun probe(): Boolean {
        return try {
            val c = open(0L, 0L, true)
            try {
                val code = c.responseCode
                contentType = c.contentType ?: contentType
                val cr = c.getHeaderField("Content-Range")
                val len = c.getHeaderField("Content-Length")?.toLongOrNull() ?: -1L
                rangeOk = code == 206
                total = if (rangeOk) (cr?.substringAfterLast('/')?.toLongOrNull() ?: -1L) else len
                if (rangeOk && total <= 0L) rangeOk = false
                code in 200..299
            } finally {
                c.disconnect()
            }
        } catch (e: Exception) {
            false
        }
    }

    private fun acceptLoop(s: ServerSocket) {
        while (running) {
            val client = try {
                s.accept()
            } catch (e: Exception) {
                break
            }
            try {
                pool.execute { handle(client) }
            } catch (e: Exception) {
                try {
                    client.close()
                } catch (e2: Exception) {
                }
                break
            }
        }
    }

    private fun readRequest(ins: InputStream): String? {
        val bos = ByteArrayOutputStream()
        var matched = 0
        while (bos.size() < 16 * 1024) {
            val b = ins.read()
            if (b < 0) return null
            bos.write(b)
            matched = when {
                (b == 13 && (matched == 0 || matched == 2)) -> matched + 1
                (b == 10 && (matched == 1 || matched == 3)) -> matched + 1
                b == 13 -> 1
                else -> 0
            }
            if (matched == 4) return bos.toString("ISO-8859-1")
        }
        return null
    }

    private fun skipFully(ins: InputStream, n: Long) {
        var left = n
        val buf = ByteArray(64 * 1024)
        while (left > 0 && running) {
            val r = ins.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
            if (r < 0) break
            left -= r
        }
    }

    private fun handle(client: Socket) {
        var conn: HttpURLConnection? = null
        var producer: Future<*>? = null
        val finished = AtomicBoolean(false)
        try {
            client.tcpNoDelay = true
            client.soTimeout = 15_000
            val request = readRequest(client.getInputStream()) ?: return
            client.soTimeout = 0

            val lines = request.split("\r\n")
            val method = lines[0].substringBefore(' ')
            var start = 0L
            var end = -1L
            var hasRange = false
            for (l in lines) {
                if (l.startsWith("range:", ignoreCase = true)) {
                    val v = l.substringAfter(':').trim().removePrefix("bytes=")
                    start = v.substringBefore('-').trim().toLongOrNull() ?: 0L
                    end = v.substringAfter('-', "").trim().toLongOrNull() ?: -1L
                    hasRange = true
                }
            }

            val out = client.getOutputStream()
            val canRange = rangeOk && total > 0L
            var status = "200 OK"
            var from = 0L
            var to = -1L
            val extra = StringBuilder()
            if (canRange) {
                from = if (hasRange) start else 0L
                to = if (hasRange && end >= from && end < total) end else total - 1
                if (from >= total) {
                    out.write("HTTP/1.1 416 Range Not Satisfiable\r\nContent-Range: bytes */$total\r\nConnection: close\r\n\r\n".toByteArray())
                    out.flush()
                    return
                }
                if (hasRange) {
                    status = "206 Partial Content"
                    extra.append("Content-Range: bytes $from-$to/$total\r\n")
                }
                extra.append("Content-Length: ${to - from + 1}\r\n")
                extra.append("Accept-Ranges: bytes\r\n")
            } else {
                if (total > 0L) extra.append("Content-Length: $total\r\n")
                extra.append("Accept-Ranges: none\r\n")
            }
            val head = "HTTP/1.1 $status\r\nContent-Type: $contentType\r\n$extra" + "Connection: close\r\n\r\n"
            out.write(head.toByteArray(Charsets.ISO_8859_1))
            out.flush()
            if (method == "HEAD") return

            // The player closes its connection when it seeks or stops. Notice that at once
            // (not only on the next write) so the old upstream connection is released.
            // Servers that allow a single connection per link would otherwise block the new one.
            val worker = Thread.currentThread()
            pool.execute {
                try {
                    val cin = client.getInputStream()
                    while (cin.read() >= 0) {
                        // ignore any extra bytes
                    }
                } catch (e: Exception) {
                }
                if (!finished.get()) {
                    try {
                        conn?.disconnect()
                    } catch (e: Exception) {
                    }
                    worker.interrupt()
                }
            }

            status = "Server: waiting for reply…"
            val t0 = System.currentTimeMillis()
            val c = if (canRange) open(from, to, true) else open(0L, 0L, false)
            conn = c
            val code = c.responseCode
            status = "Server replied $code in ${System.currentTimeMillis() - t0} ms"
            val ins = c.inputStream
            if (canRange && code == 200 && from > 0L) skipFully(ins, from)
            val toSend = if (canRange) to - from + 1 else (if (total > 0L) total else Long.MAX_VALUE)

            val queue = ArrayBlockingQueue<ByteArray>(QUEUE_CHUNKS)
            producer = pool.submit(Runnable {
                try {
                    val buf = ByteArray(CHUNK)
                    var remaining = toSend
                    while (running && remaining > 0L) {
                        val n = ins.read(buf, 0, minOf(buf.size.toLong(), remaining).toInt())
                        if (n < 0) break
                        if (n > 0) {
                            queue.put(buf.copyOf(n))
                            remaining -= n
                        }
                    }
                } catch (e: Exception) {
                } finally {
                    try {
                        queue.put(END)
                    } catch (e: InterruptedException) {
                    }
                }
            })

            while (true) {
                val chunk = queue.take()
                if (chunk === END) break
                out.write(chunk)
            }
            out.flush()
        } catch (e: Exception) {
            // client closed (seek / stop) or upstream error: just clean up
        } finally {
            finished.set(true)
            producer?.cancel(true)
            try {
                conn?.disconnect()
            } catch (e: Exception) {
            }
            try {
                client.close()
            } catch (e: Exception) {
            }
        }
    }

    companion object {
        private const val CHUNK = 128 * 1024
        private const val QUEUE_CHUNKS = 256          // ~32 MB read-ahead per connection
        private val END = ByteArray(0)
        private const val UA = "Mozilla/5.0 (Linux; Android 13) KaizenStream/3.6"
    }
}
