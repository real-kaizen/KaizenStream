package com.kaizen.stream

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class AboutActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_about)
        findViewById<View>(R.id.backBtn).setOnClickListener { finish() }

        val version = try {
            packageManager.getPackageInfo(packageName, 0).versionName ?: ""
        } catch (e: Exception) {
            ""
        }
        findViewById<TextView>(R.id.versionText).text = "v$version"

        findViewById<View>(R.id.aboutEngines).setOnClickListener {
            MaterialAlertDialogBuilder(this)
                .setTitle("Playback engines")
                .setMessage(
                    "ExoPlayer (AndroidX Media3 1.7.1)\nFast default engine.\n\n" +
                        "VLC engine (libVLC 3.6.0)\nFallback for odd MKV files, broken indexes and large files.\n\n" +
                        "FFmpeg decoders (NextLib)\nSoftware audio decoding for DTS, TrueHD and AC3."
                )
                .setPositiveButton("Close", null)
                .show()
        }
        findViewById<View>(R.id.aboutLicenses).setOnClickListener {
            MaterialAlertDialogBuilder(this)
                .setTitle("Open Source Licenses")
                .setMessage(
                    "AndroidX Media3 (Apache License 2.0)\n" +
                        "libVLC (LGPL 2.1 or later)\n" +
                        "FFmpeg through NextLib (LGPL 2.1 or later)\n" +
                        "AndroidX and Material Components (Apache License 2.0)\n" +
                        "Google Cast SDK (Google APIs Terms of Service)"
                )
                .setPositiveButton("Close", null)
                .show()
        }
    }
}
