package com.kaizen.stream

import android.content.Context

/** App-wide settings. Key names for the VLC options are unchanged from earlier versions. */
object Prefs {
    private fun sp(c: Context) =
        c.applicationContext.getSharedPreferences("kaizen_prefs", Context.MODE_PRIVATE)

    /** auto = ExoPlayer first and switch to VLC when needed, exo = ExoPlayer only, vlc = VLC only */
    fun engine(c: Context): String = sp(c).getString("engine", "auto") ?: "auto"
    fun hw(c: Context): Boolean = sp(c).getBoolean("vlc_hw", true)
    fun smart(c: Context): Boolean = sp(c).getBoolean("vlc_smart", true)
    fun bufferMs(c: Context): Int = sp(c).getInt("vlc_buffer", 8000)
    fun resume(c: Context): Boolean = sp(c).getBoolean("resume", true)
    fun scaling(c: Context): Int = sp(c).getInt("scaling", 0)
    fun speed(c: Context): Float = sp(c).getFloat("speed", 1f)
    fun audioLang(c: Context): String = sp(c).getString("audio_lang", "") ?: ""
    fun subLang(c: Context): String = sp(c).getString("sub_lang", "off") ?: "off"

    fun putString(c: Context, k: String, v: String) = sp(c).edit().putString(k, v).apply()
    fun putBool(c: Context, k: String, v: Boolean) = sp(c).edit().putBoolean(k, v).apply()
    fun putInt(c: Context, k: String, v: Int) = sp(c).edit().putInt(k, v).apply()
    fun putFloat(c: Context, k: String, v: Float) = sp(c).edit().putFloat(k, v).apply()
}
