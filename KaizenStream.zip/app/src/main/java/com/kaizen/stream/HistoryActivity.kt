package com.kaizen.stream

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class HistoryActivity : AppCompatActivity() {

    private lateinit var lib: Library
    private lateinit var adapter: LibAdapter
    private lateinit var list: ListView
    private lateinit var emptyState: View

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)
        lib = Library(this)
        list = findViewById(R.id.list)
        emptyState = findViewById(R.id.emptyState)

        adapter = LibAdapter(this, { item, fromStart ->
            Launcher.open(this, item, fromStart) { startActivity(it) }
        }, { refresh() })
        list.adapter = adapter

        list.setOnItemClickListener { parent, _, position, _ ->
            val item = parent.getItemAtPosition(position) as? LibItem ?: return@setOnItemClickListener
            Launcher.open(this, item, false) { startActivity(it) }
        }
        list.setOnItemLongClickListener { parent, view, position, _ ->
            val item = parent.getItemAtPosition(position) as? LibItem
            if (item != null) {
                RowMenu.show(this, view, item, { fromStart ->
                    Launcher.open(this, item, fromStart) { startActivity(it) }
                }, { refresh() })
            }
            true
        }

        findViewById<View>(R.id.backBtn).setOnClickListener { finish() }
        findViewById<View>(R.id.clearBtn).setOnClickListener {
            if (lib.all().isEmpty()) return@setOnClickListener
            MaterialAlertDialogBuilder(this)
                .setTitle("Clear playback history?")
                .setMessage("This removes all items and saved resume positions.")
                .setPositiveButton("Clear") { _, _ ->
                    lib.clear()
                    refresh()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        findViewById<View>(R.id.emptyAction).setOnClickListener { finish() }
        BottomNav.setup(this, R.id.navHistory)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val items = lib.all()
        adapter.clear()
        adapter.addAll(items)
        adapter.notifyDataSetChanged()
        emptyState.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
        list.visibility = if (items.isEmpty()) View.GONE else View.VISIBLE
    }
}
