package com.kaizen.stream

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.os.SystemClock
import android.util.AttributeSet
import android.view.View
import android.view.animation.AccelerateInterpolator
import android.view.animation.LinearInterpolator
import kotlin.math.min
import kotlin.math.sin

/**
 * Photorealistic-style black hole (Gargantua look): a pure-black shadow, a razor-thin photon ring,
 * the far side of the accretion disc bent over the top of the shadow (gravitational lensing),
 * a thin disc band crossing in front, Doppler-brightened on one side, over a deep star field.
 * compact = true draws only the black hole (loading indicator).
 * swallow() zooms the hole over the whole screen (page transition).
 */
class BlackHoleView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var compact = false

    /** Scroll offset in px: moves the hole up and shrinks it as the page scrolls. */
    var parallax = 0f
        set(value) {
            field = value
            invalidate()
        }

    private var zoom = 0f
    private var swallowAnim: ValueAnimator? = null

    private val starX = FloatArray(STARS)
    private val starY = FloatArray(STARS)
    private val starR = FloatArray(STARS)
    private val starA = FloatArray(STARS)
    private val starP = FloatArray(STARS)
    private val starCool = BooleanArray(STARS)

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shift = Matrix()
    private val tmpO = RectF()
    private val tmpI = RectF()

    private val pathBackBand = Path()
    private val pathFrontBand = Path()
    private val pathArcTop = Path()
    private val pathArcBottom = Path()

    private var haze: Shader? = null
    private var bandShader: LinearGradient? = null
    private var arcShader: LinearGradient? = null

    private var time = 0f
    private var startMs = 0L
    private var ticker: ValueAnimator? = null

    private var cx = 0f
    private var cy = 0f
    private var hr = 0f

    init {
        val a = context.obtainStyledAttributes(attrs, R.styleable.BlackHoleView)
        compact = a.getBoolean(R.styleable.BlackHoleView_compact, false)
        a.recycle()
        val rnd = java.util.Random(23)
        for (i in 0 until STARS) {
            starX[i] = rnd.nextFloat()
            starY[i] = rnd.nextFloat()
            starR[i] = 0.4f + rnd.nextFloat() * 0.8f
            starA[i] = 0.10f + rnd.nextFloat() * rnd.nextFloat() * 0.75f
            starP[i] = rnd.nextFloat()
            starCool[i] = rnd.nextFloat() < 0.3f
        }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val fw = w.toFloat()
        val fh = h.toFloat()
        cx = fw / 2f
        if (compact) {
            cy = fh / 2f
            hr = min(fw, fh) * 0.1f
        } else {
            cy = fh * 0.2f
            hr = min(fw, fh) * 0.13f
        }
        val r = hr

        haze = RadialGradient(
            0f, 0f, r * 4.5f,
            intArrayOf(c("#00000000"), c("#40FFC58A"), c("#22FF9F4D"), c("#103D5AFE"), c("#00000000")),
            floatArrayOf(0f, 0.2f, 0.38f, 0.7f, 1f),
            Shader.TileMode.CLAMP
        )
        // left side is the approaching side: brighter (Doppler beaming)
        bandShader = LinearGradient(
            -3.4f * r, 0f, 3.4f * r, 0f,
            intArrayOf(
                c("#00FFB060"), c("#55FFB866"), c("#CCFFE9C7"), c("#FFFFF6E6"),
                c("#FFFFE2B8"), c("#CCFFB45F"), c("#66FF8A3D"), c("#00FF7A2D")
            ),
            floatArrayOf(0f, 0.14f, 0.34f, 0.46f, 0.54f, 0.7f, 0.88f, 1f),
            Shader.TileMode.CLAMP
        )
        arcShader = LinearGradient(
            -1.42f * r, 0f, 1.42f * r, 0f,
            intArrayOf(c("#33FFD9A0"), c("#FFFFF1DA"), c("#FFFFFFFF"), c("#FFFFE4BE"), c("#99FFB866"), c("#33FF9A4D")),
            floatArrayOf(0f, 0.25f, 0.42f, 0.6f, 0.82f, 1f),
            Shader.TileMode.CLAMP
        )

        crescent(pathBackBand, 3.4f * r, 0.30f * r, 0.10f * r, true)
        crescent(pathFrontBand, 3.4f * r, 0.30f * r, 0.10f * r, false)
        crescent(pathArcTop, 1.42f * r, 1.42f * r, 1.06f * r, true)
        crescent(pathArcBottom, 1.22f * r, 1.20f * r, 1.03f * r, false)
    }

    /** A thin crescent between two half-ellipses that meet at (+-halfW, 0). */
    private fun crescent(path: Path, halfW: Float, outerH: Float, innerH: Float, top: Boolean) {
        path.reset()
        tmpO.set(-halfW, -outerH, halfW, outerH)
        tmpI.set(-halfW, -innerH, halfW, innerH)
        if (top) {
            path.arcTo(tmpO, 180f, 180f, true)
            path.arcTo(tmpI, 0f, -180f, false)
        } else {
            path.arcTo(tmpO, 0f, 180f, true)
            path.arcTo(tmpI, 180f, -180f, false)
        }
        path.close()
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (!compact) {
            canvas.drawColor(Color.BLACK)
            drawStars(canvas, w, h)
        }

        val par = if (compact) 0f else parallax
        var px = cx
        var py = cy - par * 0.6f
        var sc = (1f - par / (h * 1.2f)).coerceIn(0.4f, 1f)
        val z = zoom
        if (z > 0f) {
            px += (w / 2f - px) * z
            py += (h / 2f - py) * z
            sc *= 1f + z * z * 20f
        }
        canvas.save()
        canvas.translate(px, py)
        canvas.scale(sc, sc)
        drawHole(canvas)
        canvas.restore()

        if (z > 0.7f) {
            paint.shader = null
            paint.style = Paint.Style.FILL
            paint.color = Color.BLACK
            paint.alpha = (((z - 0.7f) / 0.3f).coerceIn(0f, 1f) * 255).toInt()
            canvas.drawRect(0f, 0f, w, h, paint)
        }
    }

    private fun drawStars(canvas: Canvas, w: Float, h: Float) {
        val d = resources.displayMetrics.density
        paint.style = Paint.Style.FILL
        paint.shader = null
        for (i in 0 until STARS) {
            val tw = 0.85f + 0.15f * sin(time * (0.5f + starP[i] * 0.5f) + starP[i] * 6.28f)
            paint.color = if (starCool[i]) Color.rgb(190, 205, 255) else Color.WHITE
            paint.alpha = (starA[i] * tw * 255).toInt().coerceIn(0, 255)
            canvas.drawCircle(starX[i] * w, starY[i] * h, starR[i] * d, paint)
        }
    }

    private fun glowFill(canvas: Canvas, path: Path, shader: Shader?, k: Float) {
        paint.shader = shader
        paint.style = Paint.Style.STROKE
        for (i in 3 downTo 1) {
            paint.strokeWidth = hr * 0.05f * i
            paint.alpha = (60f * k / i).toInt().coerceIn(0, 255)
            canvas.drawPath(path, paint)
        }
        paint.style = Paint.Style.FILL
        paint.alpha = (255f * k).toInt().coerceIn(0, 255)
        canvas.drawPath(path, paint)
    }

    private fun drawHole(canvas: Canvas) {
        val r = hr
        val pulse = 0.93f + 0.07f * sin(time * 0.8f)
        shift.setTranslate(sin(time * 0.35f) * 0.1f * r, 0f)
        bandShader?.setLocalMatrix(shift)

        canvas.save()
        canvas.rotate(-6f)

        // faint warm haze (bloom)
        paint.style = Paint.Style.FILL
        paint.shader = haze
        paint.alpha = 255
        canvas.drawCircle(0f, 0f, r * 4.5f, paint)

        // far side of the disc (wings) and its lensed image over / under the shadow
        glowFill(canvas, pathBackBand, bandShader, pulse)
        glowFill(canvas, pathArcTop, arcShader, pulse)
        glowFill(canvas, pathArcBottom, arcShader, 0.5f * pulse)

        // event horizon shadow
        paint.shader = null
        paint.style = Paint.Style.FILL
        paint.color = Color.BLACK
        canvas.drawCircle(0f, 0f, r, paint)

        // photon ring
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = r * 0.1f
        paint.color = c("#FFD9A0")
        paint.alpha = 40
        canvas.drawCircle(0f, 0f, r * 1.02f, paint)
        paint.strokeWidth = r * 0.022f
        paint.color = c("#FFF4E0")
        paint.alpha = 210
        canvas.drawCircle(0f, 0f, r * 1.012f, paint)

        // near side of the disc crossing in front of the shadow
        glowFill(canvas, pathFrontBand, bandShader, pulse)

        canvas.restore()
        paint.shader = null
    }

    /** Zooms the hole over the screen, then calls onEnd (used to open the next screen). */
    fun swallow(onProgress: (Float) -> Unit, onEnd: () -> Unit) {
        swallowAnim?.cancel()
        var cancelled = false
        swallowAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 750
            interpolator = AccelerateInterpolator(1.6f)
            addUpdateListener {
                zoom = it.animatedValue as Float
                onProgress(zoom)
                invalidate()
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationCancel(animation: Animator) {
                    cancelled = true
                }

                override fun onAnimationEnd(animation: Animator) {
                    if (!cancelled) onEnd()
                }
            })
            start()
        }
    }

    fun reset() {
        swallowAnim?.cancel()
        zoom = 0f
        invalidate()
    }

    private fun startAnim() {
        if (ticker == null) {
            startMs = SystemClock.uptimeMillis()
            ticker = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 30_000
                repeatCount = ValueAnimator.INFINITE
                interpolator = LinearInterpolator()
                addUpdateListener {
                    time = (SystemClock.uptimeMillis() - startMs) / 1000f
                    invalidate()
                }
            }
        }
        if (ticker?.isStarted != true) ticker?.start()
    }

    private fun stopAnim() {
        ticker?.cancel()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (visibility == VISIBLE) startAnim()
    }

    override fun onDetachedFromWindow() {
        stopAnim()
        swallowAnim?.cancel()
        super.onDetachedFromWindow()
    }

    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        if (visibility == VISIBLE && isAttachedToWindow) startAnim() else stopAnim()
    }

    companion object {
        private const val STARS = 140

        private fun c(hex: String): Int = Color.parseColor(hex)

        /** Y position just below the black hole on full-screen backgrounds. */
        fun holeBottomPx(ctx: Context): Int {
            val dm = ctx.resources.displayMetrics
            val w = dm.widthPixels.toFloat()
            val h = dm.heightPixels.toFloat()
            return (h * 0.2f + min(w, h) * 0.13f * 1.9f).toInt()
        }
    }
}
