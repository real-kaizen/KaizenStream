package com.kaizen.stream

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Animated black hole with a glowing, rotating accretion disc over a twinkling star field.
 * compact = true draws only the black hole (no background), used as the loading indicator.
 */
class BlackHoleView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var compact = false
    private val starX = FloatArray(STARS)
    private val starY = FloatArray(STARS)
    private val starR = FloatArray(STARS)
    private val starP = FloatArray(STARS)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val oval = RectF()
    private val arcRect = RectF()
    private val rot = Matrix()
    private var phase = 0f
    private var anim: ValueAnimator? = null
    private var glow: Shader? = null
    private var sweep: SweepGradient? = null
    private var nebula: Shader? = null
    private var cx = 0f
    private var cy = 0f
    private var hr = 0f

    init {
        val a = context.obtainStyledAttributes(attrs, R.styleable.BlackHoleView)
        compact = a.getBoolean(R.styleable.BlackHoleView_compact, false)
        a.recycle()
        val rnd = java.util.Random(11)
        for (i in 0 until STARS) {
            starX[i] = rnd.nextFloat()
            starY[i] = rnd.nextFloat()
            starR[i] = 0.5f + rnd.nextFloat() * 1.5f
            starP[i] = rnd.nextFloat()
        }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val fw = w.toFloat()
        val fh = h.toFloat()
        cx = fw / 2f
        if (compact) {
            cy = fh / 2f
            hr = min(fw, fh) * 0.13f
        } else {
            cy = fh * 0.17f
            hr = min(fw, fh) * 0.12f
        }
        glow = RadialGradient(
            cx, cy, hr * 3.4f,
            intArrayOf(c("#00000000"), c("#B0FF8A3D"), c("#66FF5A1F"), c("#337C4DFF"), c("#00000000")),
            floatArrayOf(0f, 0.28f, 0.42f, 0.7f, 1f),
            Shader.TileMode.CLAMP
        )
        sweep = SweepGradient(
            cx, cy,
            intArrayOf(c("#FFE0B2"), c("#FF9100"), c("#B388FF"), c("#7C4DFF"), c("#FF6D00"), c("#FFE0B2")),
            floatArrayOf(0f, 0.2f, 0.45f, 0.7f, 0.9f, 1f)
        )
        nebula = RadialGradient(fw * 0.85f, fh * 0.95f, max(fw, fh) * 0.6f, c("#33651FFF"), c("#00000000"), Shader.TileMode.CLAMP)
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (!compact) {
            canvas.drawColor(c("#04020A"))
            paint.style = Paint.Style.FILL
            paint.shader = nebula
            paint.alpha = 255
            canvas.drawRect(0f, 0f, w, h, paint)
            paint.shader = null
            paint.color = Color.WHITE
            val d = resources.displayMetrics.density
            for (i in 0 until STARS) {
                val a = 0.5f + 0.5f * sin(2.0 * PI * (phase * 4f + starP[i])).toFloat()
                paint.alpha = (70 + 185 * a).toInt()
                canvas.drawCircle(starX[i] * w, starY[i] * h, starR[i] * d, paint)
            }
        }
        drawHole(canvas)
    }

    private fun drawHole(canvas: Canvas) {
        val sw = sweep ?: return
        rot.setRotate(phase * 360f, cx, cy)
        sw.setLocalMatrix(rot)

        // outer glow
        paint.style = Paint.Style.FILL
        paint.shader = glow
        paint.alpha = 255
        canvas.drawCircle(cx, cy, hr * 3.4f, paint)

        // back half of the accretion disc (layered strokes fake a bloom)
        oval.set(cx - hr * 2.3f, cy - hr * 0.62f, cx + hr * 2.3f, cy + hr * 0.62f)
        paint.style = Paint.Style.STROKE
        paint.shader = sw
        canvas.save()
        canvas.rotate(-16f, cx, cy)
        for (i in 3 downTo 0) {
            paint.strokeWidth = hr * (0.34f + 0.2f * i)
            paint.alpha = if (i == 0) 255 else 38
            canvas.drawOval(oval, paint)
        }
        canvas.restore()

        // light bent over the top of the hole
        arcRect.set(cx - hr * 1.38f, cy - hr * 1.38f, cx + hr * 1.38f, cy + hr * 1.38f)
        paint.strokeWidth = hr * 0.14f
        paint.alpha = 200
        canvas.drawArc(arcRect, 200f, 140f, false, paint)

        // event horizon + photon ring
        paint.shader = null
        paint.style = Paint.Style.FILL
        paint.color = Color.BLACK
        canvas.drawCircle(cx, cy, hr, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = hr * 0.045f
        paint.color = c("#FFD7A0")
        paint.alpha = 235
        canvas.drawCircle(cx, cy, hr * 1.02f, paint)

        // front half of the disc, passing in front of the hole
        paint.shader = sw
        paint.strokeWidth = hr * 0.34f
        paint.alpha = 255
        canvas.save()
        canvas.rotate(-16f, cx, cy)
        canvas.drawArc(oval, 0f, 180f, false, paint)
        canvas.restore()
        paint.shader = null
    }

    private fun startAnim() {
        if (anim == null) {
            anim = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 30_000
                repeatCount = ValueAnimator.INFINITE
                interpolator = LinearInterpolator()
                addUpdateListener {
                    phase = it.animatedValue as Float
                    invalidate()
                }
            }
        }
        if (anim?.isStarted != true) anim?.start()
    }

    private fun stopAnim() {
        anim?.cancel()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (visibility == VISIBLE) startAnim()
    }

    override fun onDetachedFromWindow() {
        stopAnim()
        super.onDetachedFromWindow()
    }

    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        if (visibility == VISIBLE && isAttachedToWindow) startAnim() else stopAnim()
    }

    companion object {
        private const val STARS = 140

        private fun c(hex: String): Int = Color.parseColor(hex)

        /** Y position just below the black hole on full-screen backgrounds, used to start content under it. */
        fun holeBottomPx(ctx: Context): Int {
            val dm = ctx.resources.displayMetrics
            val w = dm.widthPixels.toFloat()
            val h = dm.heightPixels.toFloat()
            return (h * 0.17f + min(w, h) * 0.12f * 1.7f).toInt()
        }
    }
}
