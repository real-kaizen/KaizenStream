package com.kaizen.stream

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.os.SystemClock
import android.util.AttributeSet
import android.view.View
import android.view.animation.AccelerateInterpolator
import android.view.animation.LinearInterpolator
import kotlin.math.max
import kotlin.math.min

/**
 * Brand mark: a black event-horizon disc with a thin ice-blue rim and hairline orbit lines over a
 * near-black sky with a few quiet stars. Flat, restrained, no glow or bloom.
 * - Backgrounds are static (no animation, no battery use).
 * - compact = true draws only the mark; its rim highlight rotates and works as the loading spinner.
 * - swallow() zooms the disc over the screen for the "Play" page transition.
 */
class BlackHoleView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var compact = false
    private var fx = 0.5f
    private var fy = 0.2f
    private var scale = 1f

    /** Scroll offset in px: moves the mark up and shrinks it as the page scrolls. */
    var parallax = 0f
        set(value) {
            field = value
            invalidate()
        }

    private var zoom = 0f
    private var swallowAnim: ValueAnimator? = null

    private val starX = FloatArray(STARS)
    private val starY = FloatArray(STARS)
    private val starR = FloatArray(STARS)
    private val starA = FloatArray(STARS)

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val orbitA = RectF()
    private val orbitB = RectF()
    private val halo = RectF()
    private val rot = Matrix()

    private var hazeShader: Shader? = null
    private var orbitShader: SweepGradient? = null
    private var frontShader: SweepGradient? = null
    private var rimShader: SweepGradient? = null

    private var time = 0f
    private var startMs = 0L
    private var ticker: ValueAnimator? = null

    private var cx = 0f
    private var cy = 0f
    private var hr = 0f

    init {
        val a = context.obtainStyledAttributes(attrs, R.styleable.BlackHoleView)
        compact = a.getBoolean(R.styleable.BlackHoleView_compact, false)
        fx = a.getFloat(R.styleable.BlackHoleView_holeX, 0.5f)
        fy = a.getFloat(R.styleable.BlackHoleView_holeY, 0.2f)
        scale = a.getFloat(R.styleable.BlackHoleView_holeScale, 1f)
        a.recycle()
        val rnd = java.util.Random(23)
        for (i in 0 until STARS) {
            starX[i] = rnd.nextFloat()
            starY[i] = rnd.nextFloat()
            starR[i] = 0.5f + rnd.nextFloat() * 0.6f
            starA[i] = 0.10f + rnd.nextFloat() * rnd.nextFloat() * 0.45f
        }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val fw = w.toFloat()
        val fh = h.toFloat()
        if (compact) {
            cx = fw / 2f
            cy = fh / 2f
            hr = min(fw, fh) * 0.2f
        } else {
            cx = fw * fx
            cy = fh * fy
            hr = min(fw, fh) * 0.12f * scale
        }
        val r = hr

        // very faint depth behind the mark (no bloom)
        hazeShader = RadialGradient(
            0f, 0f, r * 3.4f,
            intArrayOf(c("#00000000"), c("#00000000"), c("#2214243A"), c("#0E0B1422"), c("#00000000")),
            floatArrayOf(0f, 0.28f, 0.5f, 0.75f, 1f),
            Shader.TileMode.CLAMP
        )
        orbitShader = SweepGradient(
            0f, 0f,
            intArrayOf(c("#00344B68"), c("#99344B68"), c("#00344B68"), c("#66344B68"), c("#00344B68")),
            floatArrayOf(0f, 0.25f, 0.5f, 0.75f, 1f)
        )
        frontShader = SweepGradient(
            0f, 0f,
            intArrayOf(c("#00A9C7EA"), c("#B0A9C7EA"), c("#00A9C7EA"), c("#00A9C7EA")),
            floatArrayOf(0f, 0.25f, 0.5f, 1f)
        )
        // highlight on the upper left of the rim
        rimShader = SweepGradient(
            0f, 0f,
            intArrayOf(
                c("#00A9C7EA"), c("#00A9C7EA"), c("#B0A9C7EA"),
                c("#FFE9EDF4"), c("#B0A9C7EA"), c("#00A9C7EA")
            ),
            floatArrayOf(0f, 0.45f, 0.6f, 0.7f, 0.8f, 1f)
        )
        orbitA.set(-2.1f * r, -0.55f * r, 2.1f * r, 0.55f * r)
        orbitB.set(-3.0f * r, -0.8f * r, 3.0f * r, 0.8f * r)
        halo.set(-1.22f * r, -1.22f * r, 1.22f * r, 1.22f * r)
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (!compact) {
            canvas.drawColor(Color.BLACK)
            drawStars(canvas, w, h)
        }

        val par = if (compact) 0f else parallax
        var px = cx
        var py = cy - par * 0.6f
        var sc = (1f - par / (h * 1.2f)).coerceIn(0.4f, 1f)
        val z = zoom
        if (z > 0f) {
            px += (w / 2f - px) * z
            py += (h / 2f - py) * z
            sc *= 1f + z * z * 12f
        }
        canvas.save()
        canvas.translate(px, py)
        canvas.scale(sc, sc)
        drawMark(canvas)
        canvas.restore()

        if (z > 0.6f) {
            paint.shader = null
            paint.style = Paint.Style.FILL
            paint.color = Color.BLACK
            paint.alpha = (((z - 0.6f) / 0.4f).coerceIn(0f, 1f) * 255).toInt()
            canvas.drawRect(0f, 0f, w, h, paint)
        }
    }

    private fun drawStars(canvas: Canvas, w: Float, h: Float) {
        val d = resources.displayMetrics.density
        paint.style = Paint.Style.FILL
        paint.shader = null
        for (i in 0 until STARS) {
            paint.color = Color.rgb(200, 214, 235)
            paint.alpha = (starA[i] * 255).toInt().coerceIn(0, 255)
            canvas.drawCircle(starX[i] * w, starY[i] * h, starR[i] * d, paint)
        }
    }

    private fun drawMark(canvas: Canvas) {
        val r = hr
        val d = resources.displayMetrics.density
        val hair = max(1f * d, r * 0.012f)

        if (!compact) {
            paint.style = Paint.Style.FILL
            paint.shader = hazeShader
            paint.alpha = 255
            canvas.drawCircle(0f, 0f, r * 3.4f, paint)
        }

        // hairline orbit lines, tilted
        canvas.save()
        canvas.rotate(-14f)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = hair
        paint.shader = orbitShader
        paint.alpha = 255
        canvas.drawOval(orbitA, paint)
        if (!compact) {
            paint.alpha = 130
            canvas.drawOval(orbitB, paint)
        }
        canvas.restore()

        // faint lensed arc over the top of the disc
        paint.shader = null
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = hair
        paint.color = c("#A9C7EA")
        paint.alpha = 60
        canvas.drawArc(halo, 212f, 116f, false, paint)

        // the event horizon
        paint.style = Paint.Style.FILL
        paint.color = Color.BLACK
        canvas.drawCircle(0f, 0f, r, paint)

        // rim with an ice-blue highlight (rotates only when used as the loading spinner)
        rot.setRotate(if (compact) time * 240f else 0f)
        rimShader?.setLocalMatrix(rot)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = max(1.25f * d, r * 0.025f)
        paint.shader = rimShader
        paint.alpha = 255
        canvas.drawCircle(0f, 0f, r, paint)

        // near side of the orbit crossing in front of the disc
        canvas.save()
        canvas.rotate(-14f)
        paint.shader = frontShader
        paint.strokeWidth = hair * 1.4f
        canvas.drawArc(orbitA, 0f, 180f, false, paint)
        canvas.restore()
        paint.shader = null
    }

    /** Zooms the disc over the screen, then calls onEnd (used to open the next screen). */
    fun swallow(onProgress: (Float) -> Unit, onEnd: () -> Unit) {
        swallowAnim?.cancel()
        var cancelled = false
        swallowAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 450
            interpolator = AccelerateInterpolator(1.4f)
            addUpdateListener {
                zoom = it.animatedValue as Float
                onProgress(zoom)
                invalidate()
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationCancel(animation: Animator) {
                    cancelled = true
                }

                override fun onAnimationEnd(animation: Animator) {
                    if (!cancelled) onEnd()
                }
            })
            start()
        }
    }

    fun reset() {
        swallowAnim?.cancel()
        zoom = 0f
        invalidate()
    }

    private fun startAnim() {
        if (!compact) return
        if (ticker == null) {
            startMs = SystemClock.uptimeMillis()
            ticker = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 30_000
                repeatCount = ValueAnimator.INFINITE
                interpolator = LinearInterpolator()
                addUpdateListener {
                    time = (SystemClock.uptimeMillis() - startMs) / 1000f
                    invalidate()
                }
            }
        }
        if (ticker?.isStarted != true) ticker?.start()
    }

    private fun stopAnim() {
        ticker?.cancel()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (visibility == VISIBLE) startAnim()
    }

    override fun onDetachedFromWindow() {
        stopAnim()
        swallowAnim?.cancel()
        super.onDetachedFromWindow()
    }

    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        if (visibility == VISIBLE && isAttachedToWindow) startAnim() else stopAnim()
    }

    companion object {
        private const val STARS = 45

        private fun c(hex: String): Int = Color.parseColor(hex)

        fun holeBottomPx(ctx: Context): Int {
            val dm = ctx.resources.displayMetrics
            val w = dm.widthPixels.toFloat()
            val h = dm.heightPixels.toFloat()
            return (h * 0.2f + min(w, h) * 0.12f * 1.7f).toInt()
        }
    }
}
