package com.kaizen.stream

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.os.SystemClock
import android.util.AttributeSet
import android.view.View
import android.view.animation.AccelerateInterpolator
import android.view.animation.LinearInterpolator
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Animated black hole: glowing rotating accretion disc, particles spiralling in, gravitational
 * lensing, drifting nebula clouds, twinkling stars and shooting stars.
 * compact = true draws only the black hole (used as the loading indicator).
 * swallow() zooms the hole over the whole screen (page transition).
 */
class BlackHoleView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var compact = false

    /** Scroll offset in px, moves the hole up and shrinks it as the page scrolls. */
    var parallax = 0f
        set(value) {
            field = value
            invalidate()
        }

    private var zoom = 0f
    private var swallowAnim: ValueAnimator? = null

    private val starX = FloatArray(STARS)
    private val starY = FloatArray(STARS)
    private val starR = FloatArray(STARS)
    private val starP = FloatArray(STARS)

    private val pF = FloatArray(PARTICLES)
    private val pA = FloatArray(PARTICLES)
    private val pS = FloatArray(PARTICLES)
    private val pZ = FloatArray(PARTICLES)
    private val pC = IntArray(PARTICLES)

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val oval = RectF()
    private val arcRect = RectF()
    private val arcRect2 = RectF()
    private val rot = Matrix()

    private var time = 0f
    private var startMs = 0L
    private var ticker: ValueAnimator? = null

    private var glow: Shader? = null
    private var sweep: SweepGradient? = null
    private var nebulaShaders: Array<Shader?> = arrayOfNulls(3)
    private var nebR = 0f
    private var cx = 0f
    private var cy = 0f
    private var hr = 0f

    init {
        val a = context.obtainStyledAttributes(attrs, R.styleable.BlackHoleView)
        compact = a.getBoolean(R.styleable.BlackHoleView_compact, false)
        a.recycle()
        val rnd = java.util.Random(11)
        for (i in 0 until STARS) {
            starX[i] = rnd.nextFloat()
            starY[i] = rnd.nextFloat()
            starR[i] = 0.5f + rnd.nextFloat() * 1.5f
            starP[i] = rnd.nextFloat() * 6.28f
        }
        val colors = intArrayOf(
            c("#EAF1FF"), c("#8C9EFF"), c("#4FC3F7"), c("#6E8BFF"), c("#B3C5FF"), c("#FFFFFF")
        )
        for (i in 0 until PARTICLES) {
            pF[i] = rnd.nextFloat()
            pA[i] = rnd.nextFloat() * 6.28f
            pS[i] = 0.6f + rnd.nextFloat() * 0.8f
            pZ[i] = 0.6f + rnd.nextFloat() * 1.1f
            pC[i] = colors[rnd.nextInt(colors.size)]
        }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val fw = w.toFloat()
        val fh = h.toFloat()
        cx = fw / 2f
        if (compact) {
            cy = fh / 2f
            hr = min(fw, fh) * 0.11f
        } else {
            cy = fh * 0.18f
            hr = min(fw, fh) * 0.15f
        }
        // shaders are centred on the origin; the canvas is translated to the hole
        glow = RadialGradient(
            0f, 0f, hr * 4.2f,
            intArrayOf(c("#00000000"), c("#A06E8BFF"), c("#603D5AFE"), c("#33283593"), c("#1A4FC3F7"), c("#00000000")),
            floatArrayOf(0f, 0.24f, 0.36f, 0.55f, 0.8f, 1f),
            Shader.TileMode.CLAMP
        )
        sweep = SweepGradient(
            0f, 0f,
            intArrayOf(c("#EAF1FF"), c("#6E8BFF"), c("#3D5AFE"), c("#8C9EFF"), c("#4FC3F7"), c("#EAF1FF")),
            floatArrayOf(0f, 0.2f, 0.45f, 0.7f, 0.9f, 1f)
        )
        nebR = max(fw, fh) * 0.55f
        val nebColors = arrayOf("#40651FFF", "#3300B0FF", "#33E040FB")
        for (i in 0 until 3) {
            nebulaShaders[i] = RadialGradient(0f, 0f, nebR, c(nebColors[i]), c("#00000000"), Shader.TileMode.CLAMP)
        }
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val d = resources.displayMetrics.density
        if (!compact) {
            canvas.drawColor(Color.BLACK)
            drawStars(canvas, w, h, d)
            drawShootingStars(canvas, w, h, d)
        }

        val par = if (compact) 0f else parallax
        var px = cx
        var py = cy - par * 0.6f
        var sc = (1f - par / (h * 1.2f)).coerceIn(0.4f, 1f)
        val z = zoom
        if (z > 0f) {
            px += (w / 2f - px) * z
            py += (h / 2f - py) * z
            sc *= 1f + z * z * 20f
        }
        canvas.save()
        canvas.translate(px, py)
        canvas.scale(sc, sc)
        drawHole(canvas)
        canvas.restore()

        if (z > 0.7f) {
            paint.shader = null
            paint.style = Paint.Style.FILL
            paint.color = Color.BLACK
            paint.alpha = (((z - 0.7f) / 0.3f).coerceIn(0f, 1f) * 255).toInt()
            canvas.drawRect(0f, 0f, w, h, paint)
        }
    }

    private fun drawNebula(canvas: Canvas, w: Float, h: Float) {
        val bx = floatArrayOf(w * 0.15f, w * 0.9f, w * 0.4f)
        val by = floatArrayOf(h * 0.55f, h * 0.3f, h * 0.95f)
        paint.style = Paint.Style.FILL
        paint.alpha = 255
        for (i in 0 until 3) {
            canvas.save()
            canvas.translate(
                bx[i] + w * 0.08f * sin(time * 0.07f + i * 2f),
                by[i] + h * 0.05f * cos(time * 0.05f + i * 1.7f)
            )
            paint.shader = nebulaShaders[i]
            canvas.drawCircle(0f, 0f, nebR, paint)
            canvas.restore()
        }
        paint.shader = null
    }

    private fun drawStars(canvas: Canvas, w: Float, h: Float, d: Float) {
        paint.style = Paint.Style.FILL
        paint.shader = null
        paint.color = Color.WHITE
        for (i in 0 until STARS) {
            val a = 0.5f + 0.5f * sin(time * 1.2f + starP[i])
            paint.alpha = (45 + 125 * a).toInt()
            canvas.drawCircle(starX[i] * w, starY[i] * h, starR[i] * d, paint)
        }
    }

    private fun hash(x: Float): Float {
        val v = sin(x * 12.9898f) * 43758.547f
        return v - floor(v)
    }

    private fun drawShootingStars(canvas: Canvas, w: Float, h: Float, d: Float) {
        paint.style = Paint.Style.STROKE
        paint.shader = null
        paint.color = Color.WHITE
        paint.strokeWidth = 1.6f * d
        paint.strokeCap = Paint.Cap.ROUND
        for (k in 0 until 2) {
            val period = 6.5f + k * 3.1f
            val tt = time + k * 2.3f
            val cycle = floor(tt / period)
            val local = tt - cycle * period
            if (local > 0.9f) continue
            val p = local / 0.9f
            val sx = hash(cycle * 3.1f + k) * w
            val sy = hash(cycle * 7.7f + k * 5f) * h * 0.6f
            val ang = 0.5f + hash(cycle * 1.3f) * 0.5f
            val dx = cos(ang)
            val dy = sin(ang)
            val len = w * 0.25f
            val hx = sx + dx * len * p * 1.6f
            val hy = sy + dy * len * p * 1.6f
            for (s in 0 until 8) {
                val t0 = s / 8f
                val t1 = (s + 1) / 8f
                paint.alpha = ((1f - t0) * (1f - p * 0.4f) * 150).toInt()
                canvas.drawLine(hx - dx * len * t0, hy - dy * len * t0, hx - dx * len * t1, hy - dy * len * t1, paint)
            }
        }
        paint.strokeCap = Paint.Cap.BUTT
    }

    /** front = true draws particles in the lower half of the disc (in front of the hole). */
    private fun drawParticles(canvas: Canvas, front: Boolean) {
        paint.style = Paint.Style.FILL
        paint.shader = null
        canvas.save()
        canvas.rotate(-16f)
        for (i in 0 until PARTICLES) {
            val frac = (pF[i] + time * 0.05f) % 1f
            val rf = 3.1f - frac * 2.0f
            val ang = pA[i] + time * pS[i] * (2.2f / (rf * sqrt(rf)))
            val s = sin(ang)
            if ((s >= 0f) != front) continue
            val x = cos(ang) * rf * hr
            val y = s * rf * hr * 0.27f
            val fade = ((rf - 1.08f) / 0.5f).coerceIn(0f, 1f)
            paint.color = pC[i]
            paint.alpha = (fade * 235).toInt()
            canvas.drawCircle(x, y, hr * 0.022f * pZ[i], paint)
        }
        canvas.restore()
    }

    private fun drawHole(canvas: Canvas) {
        val sw = sweep ?: return
        rot.setRotate(time * 14f)
        sw.setLocalMatrix(rot)

        // outer glow, gently pulsing
        paint.style = Paint.Style.FILL
        paint.shader = glow
        paint.alpha = (225 + 30 * sin(time * 1.5f)).toInt()
        canvas.drawCircle(0f, 0f, hr * 4.2f, paint)

        drawParticles(canvas, false)

        // back half of the disc (layered strokes fake a bloom)
        oval.set(-hr * 2.4f, -hr * 0.64f, hr * 2.4f, hr * 0.64f)
        paint.style = Paint.Style.STROKE
        paint.shader = sw
        canvas.save()
        canvas.rotate(-16f)
        for (i in 4 downTo 0) {
            paint.strokeWidth = hr * (0.3f + 0.2f * i)
            paint.alpha = if (i == 0) 255 else 34
            canvas.drawOval(oval, paint)
        }
        canvas.restore()

        // lensed light bent over the top (soft + bright) and under the bottom of the hole
        arcRect.set(-hr * 1.4f, -hr * 1.4f, hr * 1.4f, hr * 1.4f)
        paint.strokeWidth = hr * 0.3f
        paint.alpha = 70
        canvas.drawArc(arcRect, 195f, 150f, false, paint)
        paint.strokeWidth = hr * 0.12f
        paint.alpha = 230
        canvas.drawArc(arcRect, 200f, 140f, false, paint)
        arcRect2.set(-hr * 1.22f, -hr * 1.22f, hr * 1.22f, hr * 1.22f)
        paint.strokeWidth = hr * 0.07f
        paint.alpha = 140
        canvas.drawArc(arcRect2, 25f, 130f, false, paint)

        // event horizon + photon rings
        paint.shader = null
        paint.style = Paint.Style.FILL
        paint.color = Color.BLACK
        canvas.drawCircle(0f, 0f, hr, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = hr * 0.13f
        paint.color = c("#6E8BFF")
        paint.alpha = 60
        canvas.drawCircle(0f, 0f, hr * 1.04f, paint)
        paint.strokeWidth = hr * 0.04f
        paint.color = c("#E6EEFF")
        paint.alpha = 240
        canvas.drawCircle(0f, 0f, hr * 1.02f, paint)

        // front half of the disc, passing in front of the hole
        paint.shader = sw
        paint.strokeWidth = hr * 0.34f
        paint.alpha = 255
        canvas.save()
        canvas.rotate(-16f)
        canvas.drawArc(oval, 0f, 180f, false, paint)
        canvas.restore()
        paint.shader = null

        drawParticles(canvas, true)
    }

    /** Zooms the hole over the screen, then calls onEnd (used to open the next screen). */
    fun swallow(onProgress: (Float) -> Unit, onEnd: () -> Unit) {
        swallowAnim?.cancel()
        var cancelled = false
        swallowAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 750
            interpolator = AccelerateInterpolator(1.6f)
            addUpdateListener {
                zoom = it.animatedValue as Float
                onProgress(zoom)
                invalidate()
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationCancel(animation: Animator) {
                    cancelled = true
                }

                override fun onAnimationEnd(animation: Animator) {
                    if (!cancelled) onEnd()
                }
            })
            start()
        }
    }

    fun reset() {
        swallowAnim?.cancel()
        zoom = 0f
        invalidate()
    }

    private fun startAnim() {
        if (ticker == null) {
            startMs = SystemClock.uptimeMillis()
            ticker = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 30_000
                repeatCount = ValueAnimator.INFINITE
                interpolator = LinearInterpolator()
                addUpdateListener {
                    time = (SystemClock.uptimeMillis() - startMs) / 1000f
                    invalidate()
                }
            }
        }
        if (ticker?.isStarted != true) ticker?.start()
    }

    private fun stopAnim() {
        ticker?.cancel()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (visibility == VISIBLE) startAnim()
    }

    override fun onDetachedFromWindow() {
        stopAnim()
        swallowAnim?.cancel()
        super.onDetachedFromWindow()
    }

    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        if (visibility == VISIBLE && isAttachedToWindow) startAnim() else stopAnim()
    }

    companion object {
        private const val STARS = 100
        private const val PARTICLES = 90

        private fun c(hex: String): Int = Color.parseColor(hex)

        /** Y position just below the black hole on full-screen backgrounds. */
        fun holeBottomPx(ctx: Context): Int {
            val dm = ctx.resources.displayMetrics
            val w = dm.widthPixels.toFloat()
            val h = dm.heightPixels.toFloat()
            return (h * 0.18f + min(w, h) * 0.15f * 1.9f).toInt()
        }
    }
}
