package com.kaizen.stream

import android.annotation.SuppressLint
import android.app.PictureInPictureParams
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.Rational
import android.view.GestureDetector
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.interfaces.IMedia
import org.videolan.libvlc.util.VLCVideoLayout
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Second playback engine (libVLC, FFmpeg based). Used for files ExoPlayer can't seek or play:
 * broken MKV indexes, AVI/WMV/FLV, odd containers, RTSP/RTMP/UDP, damaged files.
 */
class VlcPlayerActivity : AppCompatActivity() {

    private var libVLC: LibVLC? = null
    private var mp: MediaPlayer? = null
    private lateinit var vlcLayout: VLCVideoLayout
    private lateinit var errorText: TextView
    private lateinit var hudText: TextView
    private lateinit var titleText: TextView
    private lateinit var infoText: TextView
    private lateinit var controls: View
    private lateinit var loader: View
    private lateinit var playBtn: ImageView
    private lateinit var prevBtn: View
    private lateinit var nextBtn: View
    private lateinit var seekBar: SeekBar
    private lateinit var posText: TextView
    private lateinit var durText: TextView
    private lateinit var speedText: TextView
    private lateinit var aspectText: TextView
    private lateinit var unlockBtn: View
    private lateinit var audio: AudioManager
    private lateinit var gestures: GestureDetector

    private val handler = Handler(Looper.getMainLooper())
    private var controlsVisible = true
    private var locked = false
    private var scrubbing = false

    private var items: List<Entry> = emptyList()
    private var isPlaylist = false
    private var index = 0
    private var subUrl: String? = null
    private var startMs = 0L
    private var resumePlaying = true
    private var subAttached = false

    private var scaleIdx = 0
    private val scaleTypes = arrayOf(
        MediaPlayer.ScaleType.SURFACE_BEST_FIT,
        MediaPlayer.ScaleType.SURFACE_FILL,
        MediaPlayer.ScaleType.SURFACE_FIT_SCREEN
    )
    private val scaleNames = arrayOf("Fit", "Stretch", "Zoom")
    private val speeds = floatArrayOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f)

    // gesture state: 0 = none, -1 = ignored, 1 = brightness, 2 = volume, 3 = seek
    private var gestureMode = 0
    private var seekStart = 0L
    private var seekTarget = 0L
    private var startBrightness = 0.5f
    private var startVolume = 0f

    private val hideHud = Runnable { hudText.visibility = View.GONE }
    private val hideUnlock = Runnable { unlockBtn.visibility = View.GONE }
    private val hideRunnable = Runnable {
        if (mp?.isPlaying == true && !scrubbing) hideControls()
    }
    private val tick = object : Runnable {
        override fun run() {
            updateProgress()
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_vlc_player)
        vlcLayout = findViewById(R.id.vlcLayout)
        errorText = findViewById(R.id.errorText)
        hudText = findViewById(R.id.hudText)
        titleText = findViewById(R.id.titleText)
        infoText = findViewById(R.id.infoText)
        controls = findViewById(R.id.controls)
        loader = findViewById(R.id.loader)
        playBtn = findViewById(R.id.playBtn)
        prevBtn = findViewById(R.id.prevBtn)
        nextBtn = findViewById(R.id.nextBtn)
        seekBar = findViewById(R.id.seekBar)
        posText = findViewById(R.id.posText)
        durText = findViewById(R.id.durText)
        speedText = findViewById(R.id.speedText)
        aspectText = findViewById(R.id.aspectText)
        unlockBtn = findViewById(R.id.unlockBtn)
        audio = getSystemService(AUDIO_SERVICE) as AudioManager

        if (intent.getBooleanExtra(PlayerActivity.EXTRA_PLAYLIST, false)) {
            items = PlaylistHolder.entries
            isPlaylist = true
            index = intent.getIntExtra(PlayerActivity.EXTRA_INDEX, 0).coerceIn(0, (items.size - 1).coerceAtLeast(0))
        } else {
            val url = intent.getStringExtra(PlayerActivity.EXTRA_URL) ?: intent.dataString ?: ""
            if (url.isNotBlank()) {
                val name = Uri.decode(url.substringBefore('?').trimEnd('/').substringAfterLast('/'))
                items = listOf(Entry(name, url))
            }
            subUrl = intent.getStringExtra(PlayerActivity.EXTRA_SUB)
        }
        if (items.isEmpty()) {
            finish()
            return
        }
        startMs = intent.getLongExtra(PlayerActivity.EXTRA_START, 0L)
        savedInstanceState?.let {
            index = it.getInt("idx", index)
            startMs = it.getLong("pos", startMs)
            resumePlaying = it.getBoolean("play", true)
        }

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        errorText.setOnClickListener { retry() }

        setupControls()
        setupGestures()
        hideSystemBars()
    }

    override fun onStart() {
        super.onStart()
        initPlayer()
        showControls()
        handler.post(tick)
    }

    override fun onStop() {
        super.onStop()
        handler.removeCallbacks(tick)
        handler.removeCallbacks(hideRunnable)
        releasePlayer()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        mp?.let {
            startMs = it.time
            resumePlaying = it.isPlaying
        }
        outState.putInt("idx", index)
        outState.putLong("pos", startMs)
        outState.putBoolean("play", resumePlaying)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (Build.VERSION.SDK_INT >= 26 && mp?.isPlaying == true) enterPip()
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        if (isInPictureInPictureMode) {
            controls.visibility = View.GONE
            unlockBtn.visibility = View.GONE
            hudText.visibility = View.GONE
        } else {
            if (locked) showUnlock() else showControls()
        }
    }

    private fun hideSystemBars() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            hide(WindowInsetsCompat.Type.systemBars())
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    // ---------- engine ----------

    private fun initPlayer() {
        if (mp != null) return
        val lib = LibVLC(this, arrayListOf("--http-reconnect", "--network-caching=2000"))
        val player = MediaPlayer(lib)
        player.attachViews(vlcLayout, null, true, false)
        player.setEventListener { e -> onVlcEvent(e) }
        libVLC = lib
        mp = player
        playCurrent(startMs, resumePlaying)
    }

    private fun playCurrent(startAt: Long, autoPlay: Boolean) {
        val lib = libVLC ?: return
        val p = mp ?: return
        val item = items[index]
        titleText.text = item.title
        errorText.visibility = View.GONE
        infoText.text = ""
        subAttached = false
        val media = Media(lib, Uri.parse(item.url))
        media.setHWDecoderEnabled(true, false)
        media.addOption(":http-user-agent=Mozilla/5.0 (Linux; Android 13) KaizenStream/3.1")
        if (startAt > 1000) media.addOption(":start-time=${startAt / 1000.0}")
        p.media = media
        media.release()
        if (autoPlay) p.play()
        p.setRate(speeds[2])
        speedText.text = "1x"
        updateNavButtons()
        updatePlayIcon()
    }

    private fun loadIndex(i: Int) {
        if (i < 0 || i >= items.size) return
        index = i
        startMs = 0L
        playCurrent(0L, true)
    }

    private fun onVlcEvent(e: MediaPlayer.Event) {
        when (e.type) {
            MediaPlayer.Event.Buffering -> {
                loader.visibility = if (e.buffering < 100f) View.VISIBLE else View.GONE
            }
            MediaPlayer.Event.Playing -> {
                loader.visibility = View.GONE
                errorText.visibility = View.GONE
                updatePlayIcon()
                attachSubtitleOnce()
                refreshInfo()
                if (controlsVisible) scheduleHide()
            }
            MediaPlayer.Event.Paused -> {
                updatePlayIcon()
                handler.removeCallbacks(hideRunnable)
            }
            MediaPlayer.Event.EndReached -> {
                if (index < items.size - 1) loadIndex(index + 1)
                else {
                    updatePlayIcon()
                    showControls()
                }
            }
            MediaPlayer.Event.EncounteredError -> {
                loader.visibility = View.GONE
                errorText.text = "The VLC engine can't play this either\n\nTap to retry"
                errorText.visibility = View.VISIBLE
                showControls()
            }
        }
    }

    private fun attachSubtitleOnce() {
        val sub = subUrl
        if (subAttached || sub.isNullOrBlank() || isPlaylist) return
        subAttached = true
        mp?.addSlave(IMedia.Slave.Type.Subtitle, Uri.parse(sub), true)
    }

    private fun refreshInfo() {
        val vt = mp?.currentVideoTrack ?: return
        val parts = ArrayList<String>()
        if (vt.height > 0) parts.add("${vt.height}p")
        val codec = vt.codec
        if (!codec.isNullOrBlank()) parts.add(codec.uppercase())
        parts.add("VLC engine")
        infoText.text = parts.joinToString("  •  ")
    }

    private fun releasePlayer() {
        val p = mp
        if (p != null) {
            startMs = p.time
            resumePlaying = p.isPlaying
            p.setEventListener(null)
            p.stop()
            p.detachViews()
            p.release()
        }
        libVLC?.release()
        mp = null
        libVLC = null
    }

    private fun retry() {
        errorText.visibility = View.GONE
        playCurrent(0L, true)
    }

    private fun switchToExo() {
        val pos = mp?.time ?: startMs
        val i = Intent(this, PlayerActivity::class.java)
        if (isPlaylist) {
            i.putExtra(PlayerActivity.EXTRA_PLAYLIST, true).putExtra(PlayerActivity.EXTRA_INDEX, index)
        } else {
            i.putExtra(PlayerActivity.EXTRA_URL, items[0].url)
            if (subUrl != null) i.putExtra(PlayerActivity.EXTRA_SUB, subUrl)
        }
        i.putExtra(PlayerActivity.EXTRA_START, pos)
        startActivity(i)
        finish()
    }

    // ---------- control bar ----------

    private fun setupControls() {
        findViewById<View>(R.id.backBtn).setOnClickListener { finish() }
        val pipBtn = findViewById<View>(R.id.pipBtn)
        if (Build.VERSION.SDK_INT >= 26 &&
            packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)
        ) pipBtn.setOnClickListener { enterPip() }
        else pipBtn.visibility = View.GONE

        playBtn.setOnClickListener { togglePlay() }
        findViewById<View>(R.id.rewBtn).setOnClickListener { seekBy(-10_000); scheduleHide() }
        findViewById<View>(R.id.fwdBtn).setOnClickListener { seekBy(10_000); scheduleHide() }
        prevBtn.setOnClickListener { loadIndex(index - 1); scheduleHide() }
        nextBtn.setOnClickListener { loadIndex(index + 1); scheduleHide() }

        findViewById<View>(R.id.speedBtn).setOnClickListener { showSpeedDialog() }
        findViewById<View>(R.id.audioBtn).setOnClickListener { showAudioDialog() }
        findViewById<View>(R.id.subBtn).setOnClickListener { showSubtitleDialog() }
        findViewById<View>(R.id.aspectBtn).setOnClickListener { cycleScale(); scheduleHide() }
        findViewById<View>(R.id.rotateBtn).setOnClickListener { rotate(); scheduleHide() }
        findViewById<View>(R.id.lockBtn).setOnClickListener { lock() }
        findViewById<View>(R.id.engineBtn).setOnClickListener { switchToExo() }
        unlockBtn.setOnClickListener { unlock() }

        seekBar.keyProgressIncrement = 10_000
        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                posText.text = fmt(progress.toLong())
                if (!scrubbing) {
                    mp?.setTime(progress.toLong())
                    scheduleHide()
                }
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {
                scrubbing = true
                handler.removeCallbacks(hideRunnable)
            }

            override fun onStopTrackingTouch(sb: SeekBar?) {
                mp?.setTime((sb?.progress ?: 0).toLong())
                scrubbing = false
                scheduleHide()
            }
        })
    }

    private fun showControls() {
        if (locked) return
        controlsVisible = true
        controls.animate().cancel()
        controls.visibility = View.VISIBLE
        controls.animate().alpha(1f).setDuration(180).start()
        updatePlayIcon()
        updateNavButtons()
        updateProgress()
        if (!packageManager.hasSystemFeature(PackageManager.FEATURE_TOUCHSCREEN) && !playBtn.isFocused) {
            playBtn.requestFocus()
        }
        scheduleHide()
    }

    private fun hideControls() {
        controlsVisible = false
        handler.removeCallbacks(hideRunnable)
        controls.animate().cancel()
        controls.animate().alpha(0f).setDuration(180).withEndAction {
            if (!controlsVisible) controls.visibility = View.GONE
        }.start()
    }

    private fun scheduleHide() {
        handler.removeCallbacks(hideRunnable)
        handler.postDelayed(hideRunnable, 4000)
    }

    private fun togglePlay() {
        val p = mp ?: return
        if (p.isPlaying) p.pause() else p.play()
        updatePlayIcon()
        scheduleHide()
    }

    private fun seekBy(deltaMs: Long) {
        val p = mp ?: return
        val len = p.length
        val target = p.time + deltaMs
        p.setTime(if (len > 0) target.coerceIn(0L, len) else target.coerceAtLeast(0L))
    }

    private fun updatePlayIcon() {
        playBtn.setImageResource(if (mp?.isPlaying == true) R.drawable.ic_pause else R.drawable.ic_play)
    }

    private fun updateNavButtons() {
        val multi = items.size > 1
        prevBtn.visibility = if (multi) View.VISIBLE else View.GONE
        nextBtn.visibility = if (multi) View.VISIBLE else View.GONE
    }

    private fun updateProgress() {
        val p = mp ?: return
        if (!controlsVisible || scrubbing) return
        val len = p.length
        val cur = p.time
        if (len <= 0) {
            seekBar.visibility = View.INVISIBLE
            posText.text = fmt(cur)
            durText.text = "LIVE"
            return
        }
        val max = len.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
        seekBar.visibility = View.VISIBLE
        seekBar.max = max
        seekBar.progress = cur.coerceIn(0L, max.toLong()).toInt()
        posText.text = fmt(cur)
        durText.text = fmt(len)
    }

    // ---------- lock ----------

    private fun lock() {
        locked = true
        hideControls()
        showUnlock()
    }

    private fun unlock() {
        locked = false
        handler.removeCallbacks(hideUnlock)
        unlockBtn.visibility = View.GONE
        showControls()
    }

    private fun showUnlock() {
        unlockBtn.visibility = View.VISIBLE
        handler.removeCallbacks(hideUnlock)
        handler.postDelayed(hideUnlock, 2500)
    }

    // ---------- dialogs ----------

    private fun choose(title: String, labels: Array<String>, checked: Int, onPick: (Int) -> Unit) {
        handler.removeCallbacks(hideRunnable)
        MaterialAlertDialogBuilder(this)
            .setTitle(title)
            .setSingleChoiceItems(labels, checked) { d, which ->
                onPick(which)
                d.dismiss()
            }
            .setNegativeButton("Close", null)
            .setOnDismissListener { if (controlsVisible) scheduleHide() }
            .show()
    }

    private fun speedLabel(v: Float): String = if (v == 1f) "1x" else "${v}x"

    private fun showSpeedDialog() {
        val p = mp ?: return
        val labels = speeds.map { if (it == 1f) "Normal" else "${it}x" }.toTypedArray()
        var checked = speeds.indexOfFirst { abs(it - p.rate) < 0.01f }
        if (checked < 0) checked = 2
        choose("Playback speed", labels, checked) { which ->
            p.setRate(speeds[which])
            speedText.text = speedLabel(speeds[which])
        }
    }

    private fun showAudioDialog() {
        val p = mp ?: return
        val tracks = p.audioTracks
        if (tracks == null || tracks.isEmpty()) {
            toast("No audio tracks in this video")
            return
        }
        val labels = tracks.map { it.name ?: "Track ${it.id}" }.toTypedArray()
        val cur = p.audioTrack
        val checked = tracks.indexOfFirst { it.id == cur }.coerceAtLeast(0)
        choose("Audio", labels, checked) { which -> p.setAudioTrack(tracks[which].id) }
    }

    private fun showSubtitleDialog() {
        val p = mp ?: return
        val tracks = p.spuTracks
        if (tracks == null || tracks.isEmpty()) {
            toast("No subtitles in this video")
            return
        }
        val labels = tracks.map { it.name ?: "Track ${it.id}" }.toTypedArray()
        val cur = p.spuTrack
        val checked = tracks.indexOfFirst { it.id == cur }.coerceAtLeast(0)
        choose("Subtitles", labels, checked) { which -> p.setSpuTrack(tracks[which].id) }
    }

    // ---------- aspect / rotate / PiP ----------

    private fun cycleScale() {
        scaleIdx = (scaleIdx + 1) % scaleTypes.size
        mp?.setVideoScale(scaleTypes[scaleIdx])
        aspectText.text = scaleNames[scaleIdx]
        showHud(scaleNames[scaleIdx])
    }

    private fun rotate() {
        val land = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        requestedOrientation = if (land) ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        else ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
    }

    private fun enterPip() {
        if (Build.VERSION.SDK_INT < 26 ||
            !packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)
        ) {
            toast("Picture-in-picture isn't supported here")
            return
        }
        try {
            enterPictureInPictureMode(
                PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build()
            )
        } catch (e: Exception) {
            Toast.makeText(this, "Turn on picture-in-picture for this app in Settings", Toast.LENGTH_LONG).show()
        }
    }

    // ---------- gestures ----------

    private fun showHud(text: String) {
        hudText.text = text
        hudText.visibility = View.VISIBLE
        hudText.removeCallbacks(hideHud)
        hudText.postDelayed(hideHud, 900)
    }

    private fun fmt(ms: Long): String {
        val s = (ms / 1000).coerceAtLeast(0)
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) String.format("%d:%02d:%02d", h, m, sec) else String.format("%02d:%02d", m, sec)
    }

    private fun currentBrightness(): Float {
        val b = window.attributes.screenBrightness
        if (b >= 0f) return b
        return try {
            Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS) / 255f
        } catch (e: Exception) {
            0.5f
        }
    }

    private fun setBrightness(v: Float) {
        val lp = window.attributes
        lp.screenBrightness = v
        window.attributes = lp
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupGestures() {
        gestures = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (controlsVisible) hideControls() else showControls()
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                val w = vlcLayout.width.toFloat()
                when {
                    e.x < w / 3f -> {
                        seekBy(-10_000)
                        showHud("⏪  10s")
                    }
                    e.x > w * 2f / 3f -> {
                        seekBy(10_000)
                        showHud("10s  ⏩")
                    }
                    else -> togglePlay()
                }
                return true
            }

            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
                val start = e1 ?: return false
                val p = mp ?: return false
                val totalX = e2.x - start.x
                val totalY = e2.y - start.y
                if (gestureMode == 0) {
                    if (abs(totalX) > abs(totalY)) {
                        gestureMode = if (p.isSeekable && p.length > 0) 3 else -1
                        seekStart = p.time
                    } else {
                        gestureMode = if (start.x < vlcLayout.width / 2f) 1 else 2
                        startBrightness = currentBrightness()
                        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                        startVolume = audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / max
                    }
                }
                val hgt = vlcLayout.height.toFloat().coerceAtLeast(1f)
                when (gestureMode) {
                    1 -> {
                        val v = (startBrightness - totalY / hgt * 1.3f).coerceIn(0.02f, 1f)
                        setBrightness(v)
                        showHud("☀  ${(v * 100).roundToInt()}%")
                    }
                    2 -> {
                        val v = (startVolume - totalY / hgt * 1.3f).coerceIn(0f, 1f)
                        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                        audio.setStreamVolume(AudioManager.STREAM_MUSIC, (v * max).roundToInt(), 0)
                        showHud("🔊  ${(v * 100).roundToInt()}%")
                    }
                    3 -> {
                        val len = p.length
                        seekTarget = (seekStart + totalX / vlcLayout.width * 90_000f).toLong().coerceIn(0L, len)
                        showHud("${fmt(seekTarget)} / ${fmt(len)}")
                    }
                }
                return true
            }
        })

        vlcLayout.setOnTouchListener { _, ev ->
            if (locked) {
                if (ev.action == MotionEvent.ACTION_UP) showUnlock()
                return@setOnTouchListener true
            }
            gestures.onTouchEvent(ev)
            if (ev.action == MotionEvent.ACTION_UP || ev.action == MotionEvent.ACTION_CANCEL) {
                if (gestureMode == 3) mp?.setTime(seekTarget)
                gestureMode = 0
            }
            true
        }
    }

    // ---------- TV remote / media keys ----------

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val p = mp
        if (p != null && event.action == KeyEvent.ACTION_DOWN) {
            when (event.keyCode) {
                KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> { togglePlay(); return true }
                KeyEvent.KEYCODE_MEDIA_PLAY -> { p.play(); return true }
                KeyEvent.KEYCODE_MEDIA_PAUSE -> { p.pause(); return true }
                KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> { seekBy(10_000); return true }
                KeyEvent.KEYCODE_MEDIA_REWIND -> { seekBy(-10_000); return true }
                KeyEvent.KEYCODE_MEDIA_NEXT, KeyEvent.KEYCODE_CHANNEL_UP, KeyEvent.KEYCODE_PAGE_UP -> {
                    loadIndex(index + 1)
                    return true
                }
                KeyEvent.KEYCODE_MEDIA_PREVIOUS, KeyEvent.KEYCODE_CHANNEL_DOWN, KeyEvent.KEYCODE_PAGE_DOWN -> {
                    loadIndex(index - 1)
                    return true
                }
            }
            if (locked) return true
            if (!controlsVisible) {
                when (event.keyCode) {
                    KeyEvent.KEYCODE_DPAD_LEFT -> { seekBy(-10_000); return true }
                    KeyEvent.KEYCODE_DPAD_RIGHT -> { seekBy(10_000); return true }
                    KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER,
                    KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN -> {
                        showControls()
                        return true
                    }
                }
            } else {
                scheduleHide()
            }
        }
        return super.dispatchKeyEvent(event)
    }
}
