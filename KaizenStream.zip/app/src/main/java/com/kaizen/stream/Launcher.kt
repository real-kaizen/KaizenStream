package com.kaizen.stream

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.widget.Toast

/** Builds the intents that open a player and loads M3U playlists. */
object Launcher {

    fun playerClass(ctx: Context): Class<*> =
        if (Prefs.engine(ctx) == "vlc") VlcPlayerActivity::class.java else PlayerActivity::class.java

    fun playIntent(ctx: Context, url: String, sub: String?, fromStart: Boolean): Intent {
        val lib = Library(ctx)
        lib.touch(url, titleOf(url), false)
        val i = Intent(ctx, playerClass(ctx)).putExtra(PlayerActivity.EXTRA_URL, url)
        if (!sub.isNullOrBlank()) i.putExtra(PlayerActivity.EXTRA_SUB, sub)
        val start = if (fromStart || !Prefs.resume(ctx)) 0L else (lib.find(url)?.pos ?: 0L)
        i.putExtra(PlayerActivity.EXTRA_START, start)
        return i
    }

    fun playlistIntent(ctx: Context, index: Int): Intent =
        Intent(ctx, playerClass(ctx))
            .putExtra(PlayerActivity.EXTRA_PLAYLIST, true)
            .putExtra(PlayerActivity.EXTRA_INDEX, index)

    fun loadPlaylist(
        act: Activity,
        url: String,
        onPlaylist: (String, List<Entry>) -> Unit,
        onDirect: () -> Unit,
        onError: (String) -> Unit
    ) {
        Thread {
            try {
                val text = Net.fetchText(url)
                if (PlaylistParser.looksLikeHls(text)) {
                    act.runOnUiThread { if (!act.isFinishing) onDirect() }
                    return@Thread
                }
                val entries = PlaylistParser.parse(text, url)
                val name = url.substringBefore('?').substringAfterLast('/').ifEmpty { "Playlist" }
                act.runOnUiThread { if (!act.isFinishing) onPlaylist(name, entries) }
            } catch (e: Exception) {
                act.runOnUiThread { if (!act.isFinishing) onError(e.message ?: "error") }
            }
        }.start()
    }

    /** Loads a playlist link, saves it to history and opens the channel list. */
    fun openPlaylistUrl(act: Activity, url: String, fromStart: Boolean, go: (Intent) -> Unit) {
        Toast.makeText(act, "Loading playlist…", Toast.LENGTH_SHORT).show()
        loadPlaylist(
            act, url,
            onPlaylist = { name, entries ->
                if (entries.isEmpty()) {
                    Toast.makeText(act, "No playable links found in this playlist", Toast.LENGTH_SHORT).show()
                } else {
                    Library(act).touch(url, name, true)
                    PlaylistHolder.title = name
                    PlaylistHolder.entries = entries
                    go(Intent(act, PlaylistActivity::class.java))
                }
            },
            onDirect = { go(playIntent(act, url, null, fromStart)) },
            onError = { Toast.makeText(act, "Can't load playlist: $it", Toast.LENGTH_SHORT).show() }
        )
    }

    fun open(act: Activity, item: LibItem, fromStart: Boolean, go: (Intent) -> Unit) {
        if (item.playlist) openPlaylistUrl(act, item.url, fromStart, go)
        else go(playIntent(act, item.url, null, fromStart))
    }
}
