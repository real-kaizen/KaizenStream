# Kaizen Stream 2.0
Android + Android TV video player for web links.
Build: push KaizenStream.zip + .github/workflows/build.yml to GitHub; the APK appears under Releases.
